-- Effect by Reguas

ScriptInfo = {
    Name = "Explode In Midair",
    ScriptId = "peds_explode_in_midair",
    TimedType = "Normal",
}

function OnStart()
    REQUEST_NAMED_PTFX_ASSET("scr_xm_orbital");
	REQUEST_NAMED_PTFX_ASSET("scr_xm_orbital_blast");
end

function OnTick()
    local cnt = 0;

    for _, ped in ipairs(GetAllPeds()) do
        if not IS_ENTITY_DEAD(ped, false) then 
            local entity = IS_PED_IN_ANY_VEHICLE(ped, false) and GET_VEHICLE_PED_IS_IN(ped, false) or ped;
            local pos = GET_ENTITY_COORDS(entity, false);

            local height = GET_ENTITY_HEIGHT_ABOVE_GROUND(entity);
            local min = Holder();
            local max = Holder();
            GET_MODEL_DIMENSIONS(GET_ENTITY_MODEL(entity), min, max);
            
            local entityHeight = max:AsVector3().z - min:AsVector3().z;
            
            local groundZ = Holder();

            if GET_GROUND_Z_FOR_3D_COORD(pos.x, pos.y, pos.z, groundZ, false, false) then
                if IS_PED_JUMPING(ped) or pos.z - groundZ:AsFloat() > entityHeight * 0.6 + 0.2 then
                    USE_PARTICLE_FX_ASSET("scr_xm_orbital");

                    START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_xm_orbital_blast", pos.x, pos.y, pos.z, 0.0, 0.0, 0.0,
                                                                    1.0, 0, 0, 0, 0);

                    PLAY_SOUND_FROM_COORD(-1, "DLC_XM_Explosions_Orbital_Cannon", pos.x, pos.y, pos.z, 0, 1, 0, 0);

                    ADD_EXPLOSION(pos.x, pos.y, pos.z, 9, 100.0, true, false, 3.0, false);

                    SET_ENTITY_HEALTH(ped, 0, false);
                    
                    cnt = cnt + 1;
                    if cnt == 5 then
                        WAIT(0);
                        cnt = 0;
                    end
                end
            end
        end
    end
end
