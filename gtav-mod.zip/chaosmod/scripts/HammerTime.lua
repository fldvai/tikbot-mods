-- Effect by OnlyRealNubs

ScriptInfo = {
	Name = "Stop! Hammer Time",
	ScriptId = "peds_hammertime",
    TimedType = "Short"
};

ped = GET_HASH_KEY("S_M_Y_Construct_02");
hammer = 1317494643;

waitTime = 1.0;
playerHasHammer = false;

function OnTick()
	DISABLE_CONTROL_ACTION(1, 37, 1);
	SET_CURRENT_PED_WEAPON(playerPed, hammer, true);
    
    riotGroupHash = GET_HASH_KEY("_HAMMERTIME");
    playerGroupHash = GET_HASH_KEY("PLAYER");

    SET_RELATIONSHIP_BETWEEN_GROUPS(5, riotGroupHash, riotGroupHash);
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, riotGroupHash, playerGroupHash);
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, playerGroupHash, riotGroupHash);

    SET_PLAYER_WANTED_LEVEL(PLAYER_ID(), 0, false);
    SET_MAX_WANTED_LEVEL(0);

    goneThroughPeds = {};

    for _, ped in ipairs(GetAllPeds()) do
        if (not IS_PED_A_PLAYER(ped)) then
            SET_PED_RELATIONSHIP_GROUP_HASH(ped, riotGroupHash);

            SET_PED_COMBAT_ATTRIBUTES(ped, 5, true);
            SET_PED_COMBAT_ATTRIBUTES(ped, 46, true);

            SET_PED_FIRING_PATTERN(ped, 0xC6EE6B4C);

            if not goneThroughPeds[ped] then
                weps = GetAllWeapons();
                GIVE_WEAPON_TO_PED(ped, hammer, 9999, false, true);

                goneThroughPeds[ped] = true;
            end
        end
    end

    for ped, _ in pairs(goneThroughPeds) do
        if not DOES_ENTITY_EXIST(ped) then
            goneThroughPeds[ped] = false;
        end
    end
end

function OnStop()
    REMOVE_RELATIONSHIP_GROUP(GET_HASH_KEY("_HAMMERTIME"));
    resetGroupHashHolder = Holder();
    ADD_RELATIONSHIP_GROUP("_HAMMERTIME_RESET", resetGroupHashHolder);
	resetGroupHash = resetGroupHashHolder:AsInteger();
    playerGroupHash = GET_HASH_KEY("PLAYER");

    SET_RELATIONSHIP_BETWEEN_GROUPS(255, resetGroupHash, resetGroupHash);
    SET_RELATIONSHIP_BETWEEN_GROUPS(255, resetGroupHash, playerGroupHash);
    SET_RELATIONSHIP_BETWEEN_GROUPS(255, playerGroupHash, resetGroupHash);

    for _, p in ipairs(GetAllPeds()) do
        if (p == PLAYER_PED_ID() and playerHasHammer == false) then
            REMOVE_WEAPON_FROM_PED(p, hammer);
        else
            REMOVE_WEAPON_FROM_PED(p, hammer);
            SET_PED_RELATIONSHIP_GROUP_HASH(p, resetGroupHash);
        end
    end

    -- Give player weapon wheel back
    DISABLE_CONTROL_ACTION(1, 37, 0);
end

function OnStart()
    groupHashHolder = Holder();
    ADD_RELATIONSHIP_GROUP("_HAMMERTIME", groupHashHolder);
	groupHash = groupHashHolder:AsInteger();

    playerPed = PLAYER_PED_ID();

    if (HAS_PED_GOT_WEAPON(playerPed, hammer, 0)) then
        SET_CURRENT_PED_WEAPON(playerPed, hammer, true);
        playerHasHammer = true;
    else
        GIVE_WEAPON_TO_PED(playerPed, hammer, 9999, false, true);
    end

    for _, ped in ipairs(GetAllPeds()) do
        if (IS_PED_IN_ANY_VEHICLE(ped, true)) then
            pedVeh = GET_VEHICLE_PED_IS_IN(ped, true);
            TASK_LEAVE_VEHICLE(ped, pedVeh, 256);
            BRING_VEHICLE_TO_HALT(pedVeh, 0.1, 10, 0);
        end
        if (ped ~= playerPed) then
            TASK_TURN_PED_TO_FACE_ENTITY(ped, playerPed, -1);
            TASK_LOOK_AT_ENTITY(ped, playerPed, -1, 2048, 3);
        end
    end

    pos = GET_ENTITY_COORDS(playerPed, 1);
    enemy = CreatePoolPed(4, ped, pos.x, pos.y, pos.z, 0.0);
    WAIT(math.floor(waitTime * 1000));
end