--[[
    Effect By: OnlyRealNubs
--]]

ScriptInfo = {
	Name = "Spawn Disingenuous Dave",
	ScriptId = "peds_spawn_dave"
};

function OnStart()
    modelHash = 0x15CD4C33;

    playerPed = PLAYER_PED_ID();
    playerPos = GET_ENTITY_COORDS(playerPed, false);

    playerGroup = GET_HASH_KEY("PLAYER");
    civGroup = GET_HASH_KEY("CIVMALE");
    femCivGroup = GET_HASH_KEY("CIVFEMALE");

    relationshipGroupHolder = Holder();
    ADD_RELATIONSHIP_GROUP("_HOSTILE_DAV", relationshipGroupHolder);
	relationshipGroup = relationshipGroupHolder:AsInteger();
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, relationshipGroup, playerGroup);
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, relationshipGroup, civGroup);
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, relationshipGroup, femCivGroup);

    ped = CreatePoolPed(4, modelHash, playerPos.x, playerPos.y, playerPos.z, 0.0);
    if (IS_PED_IN_ANY_VEHICLE(playerPed, false)) then
        SET_PED_INTO_VEHICLE(ped, GET_VEHICLE_PED_IS_IN(playerPed, false), -2);
    end

    SET_PED_RELATIONSHIP_GROUP_HASH(ped, relationshipGroup);
    SET_PED_HEARING_RANGE(ped, 9999.0);
    SET_PED_CONFIG_FLAG(ped, 281, true);

    SET_ENTITY_PROOFS(ped, false, false, false, false, false, false, false, false);

    SET_PED_COMBAT_ATTRIBUTES(ped, 5, true);
    SET_PED_COMBAT_ATTRIBUTES(ped, 46, true);

    SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(ped, false);
    SET_RAGDOLL_BLOCKING_FLAGS(ped, 5);
    SET_PED_SUFFERS_CRITICAL_HITS(ped, false);

    GIVE_WEAPON_TO_PED(ped, 0x22D8FE39, 9999, true, true); -- AP Pistol
    TASK_COMBAT_PED(ped, playerPed, 0, 16);

    SET_PED_FIRING_PATTERN(ped, 0xC6EE6B4C);
end