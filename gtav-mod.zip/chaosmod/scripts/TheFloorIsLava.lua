ScriptInfo = {
    Name = "The Floor Is Lava",
    ScriptId = "player_lavafloor",
    TimedType = "Short",
}

local player;
local lastTick;
local VehicleLastTick;
local TimeUntilNextVehicleCheck;
local TimeUntilNextMainCheck;

function OnStart()
    player = PLAYER_PED_ID();
    lastTick = GetTickCount();
    TimeUntilNextMainCheck = math.random(200, 750);
    SET_PED_CONFIG_FLAG(player, 430, true);

    --Since this effect can be hard to understand; display a help message.
    BEGIN_TEXT_COMMAND_DISPLAY_HELP("STRING");
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("Stand on peds, objects or vehicles to avoid burning in the lava. ~n~~b~You're not safe in vehicles.~b~");
    END_TEXT_COMMAND_DISPLAY_HELP(0, false, true, 10000);
end

function DamagePlayer()

    if IS_PED_IN_ANY_VEHICLE(player, false) then
        local vehicle = GET_VEHICLE_PED_IS_IN(player, false);
        SET_VEHICLE_ENGINE_HEALTH(vehicle, -1.0);
        SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, -1.0);
        return;
    end

    APPLY_DAMAGE_TO_PED(player, math.floor((GET_PED_MAX_HEALTH(player) - 100) / math.random(20, 35)), false);
    PLAY_PAIN(player, 8, 0, false);
    if not IS_ENTITY_ON_FIRE(player) then
        START_ENTITY_FIRE(player);
    end
end

function OnStop()
    SET_PED_CONFIG_FLAG(player, 430, false);
    STOP_ENTITY_FIRE(player);
end

function OnTick()
    player = PLAYER_PED_ID();
    local curTick = GetTickCount();

    if curTick - lastTick >= TimeUntilNextMainCheck then
        TimeUntilNextMainCheck = math.random(200, 750);
        lastTick = curTick;

        if IS_PED_IN_ANY_VEHICLE(player, false) then
            if VehicleLastTick == (0 or nil) then
                VehicleLastTick = curTick;
                TimeUntilNextVehicleCheck = math.random(4500, 10000);
            elseif curTick - VehicleLastTick >= TimeUntilNextVehicleCheck then
                DamagePlayer();
                VehicleLastTick = 0;
            end
        else
            VehicleLastTick = 0;
        end

        local playerPos = GET_ENTITY_COORDS(player);
        local targetCoords = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player, 0.0, 0.0, -1.5);
        local rayHandle     = START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE(playerPos.x, playerPos.y, playerPos.z, targetCoords.x, targetCoords.y, targetCoords.z, 30, player, 4);
        if rayHandle then
            local didHit, endCoords, hitCoordsNormal, entityHandle = Holder(), Holder(), Holder(), Holder();
		    local result = GET_SHAPE_TEST_RESULT(rayHandle, didHit, endCoords, hitCoordsNormal, entityHandle);
            if result == 2 then
                if didHit:AsBoolean() == false or (didHit:AsBoolean() and not DOES_ENTITY_EXIST(entityHandle:AsInteger())) then
                    DamagePlayer();
                    return;
                else
                    STOP_ENTITY_FIRE(player);
                end
            end
        end
    end
end