--[[
	Effect by Moxi
--]]

ScriptInfo = {
	Name = "Monster Head",
	ScriptId = "player_monster_head"
};

function LoadModel(ulModel)
	if IS_MODEL_VALID(ulModel) then
		REQUEST_MODEL(ulModel);
		while not HAS_MODEL_LOADED(ulModel) do
			WAIT(0);
		end
	end
end

monsterHash = GET_HASH_KEY("sum_prop_ac_monstermask_01a");

function OnStart()
	LoadModel(monsterHash);

	player = PLAYER_PED_ID();
	bone = GET_PED_BONE_INDEX(player, 0x60F2);
	playerPos = GET_ENTITY_COORDS(player, false);

	monsterHead = CREATE_OBJECT(monsterHash, playerPos.x, playerPos.y + 2, playerPos.z, true, false, false);
	ATTACH_ENTITY_TO_ENTITY(monsterHead, player, bone, 0.36, 0.1, -0.01, 180.0, -90.0, 0.0, true, false, false, false, 0, true);
	SET_ENTITY_AS_NO_LONGER_NEEDED(Holder(monsterHead));
end
