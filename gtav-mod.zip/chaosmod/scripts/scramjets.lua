--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Scramjets",
    ScriptId = "peds_scramjets",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("scramjet"), 120)
end
