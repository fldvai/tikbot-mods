--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Jetpack+",
    ScriptId = "peds_jetpack",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("thruster"), 120)
end
