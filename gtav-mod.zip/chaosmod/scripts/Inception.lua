--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Inception",
    ScriptId = "misc_inception",
    TimedType = "Normal"
};

local objects = {
    'ch2_lod2_slod3',
    'ch2_lod3_slod3',
    'ch3_lod_1_2_slod3',
    'cs1_lod_15b_slod3',
    'cs1_lod_15c_slod3',
    'cs1_lod_16_slod3',
    'cs2_lod_1234_slod3',
    'cs2_lod_5_9_slod3',
    'cs3_lod_1_slod3',
    'cs3_lod_s3_06a',
    'cs4_lod_01_slod3',
    'cs4_lod_02_slod3',
    'cs5_lod_02_slod3',
    'cs6_lod_slod3_01',
    'cs6_lod_slod3_03',
    'cs6_lod_slod3_04',
    'dt1_lod_f2_slod3',
    'dt1_lod_f2b_slod3',
    'dt1_lod_slod3',
    'hw1_lod_slod4',
    'id1_lod_slod4',
    'kt1_lod_slod4',
    'po1_lod_slod4',
    'sc1_lod_slod4',
    'sp1_lod_slod4',
    'ss1_lod_slod3',
    'vb_lod_slod4',
}

local props = {};

local xmin = 0;
local xmax = 0;
local ymin = 0;
local ymax = 0;

function rand()
    return math.random() * 2 - 1;
end

function SpawnProps(x0, x1, y0, y1, z)
    for x = x0, x1, 500.0 do
        for y = y0, y1, 500.0 do
            local model = GET_HASH_KEY(objects[math.random(#objects)]);
            LoadModel(model);
            
            local groundZHolder = Holder();
            local groundZ = z;

            if GET_GROUND_Z_FOR_3D_COORD(x, y, z + 200.0, groundZHolder, false, false) then
                groundZ = groundZHolder:AsFloat()
            end

            local prop = CREATE_OBJECT(model, x, y, groundZ + math.random(100, 600), false, false, false);
            
            local initRot = Vector3(rand() * 60.0 + 180.0, rand() * 30.0, rand() * 30.0);

            SET_ENTITY_ROTATION(prop, initRot.x, initRot.y, initRot.z, 0, false);

            table.insert(props, {prop=prop, rotationVel=Vector3(rand(), rand(), rand()), initRotation=initRot});
        end
    end
end

local radius = 2500.0

function OnStart()
    local coords = GET_ENTITY_COORDS(PLAYER_PED_ID(), false);

    xmin = coords.x - radius;
    xmax = coords.x + radius;
    ymin = coords.y - radius;
    ymax = coords.y + radius;

    SpawnProps(xmin, xmax, ymin, ymax, coords.z);
    lastTick = GET_GAME_TIMER();
end

function CheckRotationOverflow(initVal, val)
    if initVal > 180.0 then
        initVal = initVal - 180.0;
    elseif initVal < -180.0 then
        initVal = initVal + 180.0;
    end

    local low = initVal - 20;
    local high = initVal + 20;

    if low < -180.0 then
        return val > high and val < low + 180.0;
    end
    if high > 180.0 then
        return val < low and val > high - 180.0;
    end

    return val < low or val > high;
end

local lastTick = 0.0;

function OnTick()
    local spawnRadius = radius * 3 / 4;

    local coords = GET_ENTITY_COORDS(PLAYER_PED_ID(), false);
    if coords.x - xmin < spawnRadius then
        SpawnProps(coords.x - radius, xmin, ymin, ymax, coords.z);
        xmin = coords.x - radius;
    elseif xmax - coords.x < spawnRadius then
        SpawnProps(xmax, coords.x + radius, ymin, ymax, coords.z);
        xmax = coords.x + radius;
    elseif coords.y - ymin < spawnRadius then
        SpawnProps(xmin, xmax, coords.y - radius, ymin, coords.z);
        ymin = coords.y - radius;
    elseif ymax - coords.y < spawnRadius then
        SpawnProps(xmin, xmax, ymax, coords.y + radius, coords.z);
        ymax = coords.y + radius;
    end

    local time = math.min((GET_GAME_TIMER() - lastTick) / 1000.0, 1);

    lastTick = GET_GAME_TIMER();
    for _, prop in ipairs(props) do
        local rot = GET_ENTITY_ROTATION(prop.prop, 0);
        rot.x = rot.x + prop.rotationVel.x * time;
        rot.y = rot.y + prop.rotationVel.y * time;
        rot.z = rot.z + prop.rotationVel.z * time;
        if CheckRotationOverflow(prop.initRotation.x, rot.x) then
            prop.rotationVel.x = -prop.rotationVel.x;
        end
        if CheckRotationOverflow(prop.initRotation.y, rot.y) then
            prop.rotationVel.y = -prop.rotationVel.y;
        end
        if CheckRotationOverflow(prop.initRotation.z, rot.z) then
            prop.rotationVel.z = -prop.rotationVel.z;
        end

        SET_ENTITY_ROTATION(prop.prop, rot.x, rot.y, rot.z, 0, false);
    end

end

function OnStop()
    for _, prop in ipairs(props) do
        DELETE_OBJECT(Holder(prop.prop))
    end

    props = {};
end