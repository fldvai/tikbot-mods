--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Bicycles",
    ScriptId = "peds_cycles",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("cruiser"), 120)
end
