--[[
    Effect by Reguas
--]]

ScriptInfo = {
	Name = "Wiggle-Wiggle",
	ScriptId = "vehs_wiggle_wiggle",
    TimedType = "Normal"
};

lastTick = 0;
flag = false;

function OnTick()
    currentTick = GET_GAME_TIMER();

    if (currentTick - lastTick >= 1000) then
        for _, veh in ipairs(GetAllVehicles()) do
            if (not IS_VEHICLE_SEAT_FREE(veh, -1, false) and GET_ENTITY_SPEED(veh) > 0.1) then
                TASK_VEHICLE_TEMP_ACTION(GET_PED_IN_VEHICLE_SEAT(veh, -1, false), veh, flag and 7 or 8, 250); -- 7 = left; 8 = right
            end
        end
        flag = not flag;
        lastTick = currentTick;
    end
end