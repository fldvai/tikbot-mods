--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Party Bus",
    ScriptId = "peds_party",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("pbus2"), 120)
end
