--[[
    Effect by Gorakh
--]]

ScriptInfo = {
	Name = "Stage Lighting",
	ScriptId = "misc_spotlight",
    TimedType = "Normal"
};

function DrawSpotlightForEntity(entity)
    minHolder, maxHolder = Holder(), Holder();
    GET_MODEL_DIMENSIONS(GET_ENTITY_MODEL(entity), minHolder, maxHolder);
	min, max = minHolder:AsVector3(), maxHolder:AsVector3();
    modelSize = Vector3(max.x - min.x, max.y - min.y, max.z - min.z);
	
    modelCenterLocalPos = Vector3((max.x + min.x) / 2.0, (max.y + min.y) / 2.0, (max.z + min.z) / 2.0);
    modelCenterWorldPos = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(entity, modelCenterLocalPos.x, modelCenterLocalPos.y, modelCenterLocalPos.z);

    lightPos = modelCenterWorldPos;
    lightPos.z = lightPos.z + modelSize.z * 1.5;

    -- This is essentially the minimum "radius" we want the spotlight to have
    modelRadius = math.sqrt((modelSize.x * modelSize.x) + (modelSize.y * modelSize.y)) / 2.0;

    -- tan(spotAngle) = modelRadius / lightLocalZ;
    -- Increase modelRadius slightly to make sure the entire model is lit
    spotAngle = math.atan2(modelRadius + 0.4, GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS(entity, lightPos.x, lightPos.y, lightPos.z).z - min.z);

    -- Lazy radians to degree conversion, but accuracy isn't really of concern here
    spotAngle = spotAngle * 57.295;

    DRAW_SPOT_LIGHT(lightPos.x, lightPos.y, lightPos.z, 0.0, 0.0, -1.0, 255, 255, 255, 10.0, 150.0, 1.0, spotAngle, 0.0);
end

function OnTick()
    SET_CLOCK_TIME(0, 0, 0);
    SET_ARTIFICIAL_LIGHTS_STATE(true);

    for _, ped in ipairs(GetAllPeds()) do
        if (not IS_PED_IN_ANY_VEHICLE(ped, false)) then
            DrawSpotlightForEntity(ped);
        end
    end

    for _, veh in ipairs(GetAllVehicles()) do
        DrawSpotlightForEntity(veh);
    end

    -- Decrease screen "brightness"
    DRAW_RECT(0.5, 0.5, 1.0, 1.0, 0, 0, 0, 140, 0);
end

function OnStop()
    SET_ARTIFICIAL_LIGHTS_STATE(false);
end