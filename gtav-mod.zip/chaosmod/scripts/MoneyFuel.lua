--[[
	Effect by Gorakh
--]]

ScriptInfo = {
	Name = "Money Fuel",
	ScriptId = "player_money_is_fuel",
	TimedType = "Normal"
};


function OnTick()
	playerPed = PLAYER_PED_ID();
	if (DOES_ENTITY_EXIST(playerPed) and not IS_ENTITY_DEAD(playerPed, 0) and IS_PED_IN_ANY_VEHICLE(playerPed, false)) then
		playerVeh = GET_VEHICLE_PED_IS_IN(playerPed, false);
		if (GET_IS_VEHICLE_ENGINE_RUNNING(playerVeh)) then
			for _, hash in ipairs({ GET_HASH_KEY("SP0_TOTAL_CASH"), GET_HASH_KEY("SP1_TOTAL_CASH"), GET_HASH_KEY("SP2_TOTAL_CASH") }) do
				moneyHolder = Holder();
				if (STAT_GET_INT(hash, moneyHolder, -1)) then
				    money = moneyHolder:AsInteger();
					moneyToDrain = GET_ENTITY_SPEED(playerVeh) * 0.9;
					if (moneyToDrain > 0) then
						money = money - moneyToDrain;
						money = math.max(money, 0);
						STAT_SET_INT(hash, math.floor(money), true);
						if (money == 0) then
							SET_VEHICLE_ENGINE_HEALTH(playerVeh, 0.0);
						end

						DISPLAY_CASH(true);
					end
				end
			end
		end
	end
end