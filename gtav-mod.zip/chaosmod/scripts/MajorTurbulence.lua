-- Effect by casperge

ScriptInfo = {
	Name = "Major Turbulence",
	ScriptId = "misc_major_turbulence",
	TimedType = "Normal"
};


spawnTimer = -1;
currenttick = 1;

function LoadModel(ulModel)
	if IS_MODEL_VALID(ulModel) then
		REQUEST_MODEL(ulModel);
		while not HAS_MODEL_LOADED(ulModel) do
			WAIT(0);
		end
	end
end

function OnStart()
	miljethash = GET_HASH_KEY("luxor");
	pilothash = GET_HASH_KEY("s_m_m_pilot_01");
end

function OnTick()

	LoadModel(miljethash);
	LoadModel(pilothash);
	current_time = GET_GAME_TIMER();

	currenttick = currenttick + 1;
	if (current_time > spawnTimer + 4000) then
		spawnTimer = current_time;
		playerPos = GET_ENTITY_COORDS(PLAYER_PED_ID(), true);
		offsetx = math.random(-85, 85);
		offsety = math.random(-85, 85);
		variant = math.random(0, 4);
		spawnOffsetX = 0;
		spawnOffsetY = 0;
		rotation = 90.0 * variant;
		if (variant % 2 == 0) then
			spawnOffsetY = variant == 0 and -400 or 400;
		else
			spawnOffsetX = variant == 3 and -400 or 400;
		end

		veh = CreatePoolVehicle(miljethash, playerPos.x + offsetx + spawnOffsetX, playerPos.y + offsety + spawnOffsetY, playerPos.z + 400, rotation);

		driver = CREATE_PED_INSIDE_VEHICLE(veh, -1, pilothash, -1, true, false);
		SET_VEHICLE_FORWARD_SPEED(veh, 55);
		SET_VEHICLE_ENGINE_ON(veh, true, true, false);
		SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(driver, true);

		TASK_VEHICLE_MISSION_PED_TARGET(driver, veh, PLAYER_PED_ID(), 21, 9999, 17039360, 0, 0, false);
	end
	entityCoord = GET_ENTITY_COORDS(veh, false);
	playerCoord = GET_ENTITY_COORDS(PLAYER_PED_ID(), false);
	if (not GET_DOES_VEHICLE_HAVE_DAMAGE_DECALS(veh) and currenttick % 7 == 1 and GET_DISTANCE_BETWEEN_COORDS(entityCoord.x, entityCoord.y, entityCoord.z, playerCoord.x, playerCoord.y, playerCoord.z, true) > 150.0) then
		APPLY_FORCE_TO_ENTITY(veh, 1, (entityCoord.x - (playerCoord.x + offsetx)) * -1, (entityCoord.y - (playerCoord.y + offsety)) * -1, (entityCoord.z - playerCoord.z) * -1, 0, 0, 0, 0, 0, 1, 0, 0, 1);
	end
end