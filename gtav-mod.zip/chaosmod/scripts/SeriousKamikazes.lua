--[[
	Effect by Moxi based on Killer Clowns by Last0xygen, and a lot of help and suggestions!
--]]

ScriptInfo = {
	Name = "Serious Kamikazes",
	ScriptId = "peds_seriouskamikazes",
	TimedType = "Short"
};

kamiBomb = {};
spawnTimer = -1;
maxKamikazesToSpawn = 5;

relationshipGroup = 0;

kamikazeHash = GET_HASH_KEY("a_m_y_musclbeac_01");
bombHash = GET_HASH_KEY("imp_prop_bomb_ball");

animDict = "missminuteman_1ig_2";

function LoadModel(ulModel)
	if IS_MODEL_VALID(ulModel) then
		REQUEST_MODEL(ulModel);
		while not HAS_MODEL_LOADED(ulModel) do
			WAIT(0);
		end
	end
end

function OnStop()
	for kamikaze, bomb in pairs(kamiBomb) do
		SET_PED_AS_NO_LONGER_NEEDED(Holder(kamikaze));
		SET_ENTITY_AS_NO_LONGER_NEEDED(Holder(bomb));
	end
end

function OnStart()
	playerGroup = GET_HASH_KEY("PLAYER");
	relationshipGroupHolder = Holder();
	ADD_RELATIONSHIP_GROUP("_HOSTILE_SERIOUS_KAMIKAZES", relationshipGroupHolder);
	relationshipGroup = relationshipGroupHolder:AsInteger();
	SET_RELATIONSHIP_BETWEEN_GROUPS(5, relationshipGroup, playerGroup);
	SET_RELATIONSHIP_BETWEEN_GROUPS(5, playerGroup, relationshipGroup);
	SET_RELATIONSHIP_BETWEEN_GROUPS(0, relationshipGroup, relationshipGroup);
end

function GetCoordAround(entity, angle, radius, zOffset, relative)
	if (relative) then
		offset = Vector3(-radius * math.sin(angle + 90), radius * math.sin(angle), zOffset);

		return GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(entity, offset.x, offset.y, offset.z);
	else
		entityPosition = GET_ENTITY_COORDS(entity, false);
		return Vector3(entityPosition.x - radius * math.sin(angle + 90), entityPosition.y + radius * math.sin(angle),
								entityPosition.z + zOffset);
	end
end

function OnTick()
	playerPed = PLAYER_PED_ID();
	playerPos = GET_ENTITY_COORDS(playerPed, false);
	current_time = GET_GAME_TIMER();

	for kamikaze, bomb in pairs(kamiBomb) do
		kamikazePos = GET_ENTITY_COORDS(kamikaze, false);
		if (IS_PED_DEAD_OR_DYING(kamikaze, false) or IS_PED_INJURED(kamikaze) or GET_DISTANCE_BETWEEN_COORDS(playerPos.x, playerPos.y, playerPos.z, kamikazePos.x, kamikazePos.y, kamikazePos.z, false) > 100.0) then
			SET_ENTITY_HEALTH(kamikaze, 0, 0);
			SET_ENTITY_ALPHA(kamikaze, 0, true);
			SET_PED_AS_NO_LONGER_NEEDED(Holder(kamikaze));
			DELETE_PED(Holder(kamikaze));
			DELETE_ENTITY(Holder(bomb));
			WAIT(0);
		end
	end

	if (#kamiBomb < maxKamikazesToSpawn and current_time > spawnTimer + 2000) then
		spawnTimer = current_time;
		spawnPos = GetCoordAround(playerPed, math.random(0, 360), 15, 0, true);
		USE_PARTICLE_FX_ASSET("core");
		START_PARTICLE_FX_NON_LOOPED_AT_COORD("exp_air_molotov", spawnPos.x, spawnPos.y, spawnPos.z, 0, 0, 0, 2, true, true, true);
		WAIT(300);
		LoadModel(kamikazeHash);
		ped = CREATE_PED(-1, kamikazeHash, spawnPos.x, spawnPos.y, spawnPos.z, 0, true, false);
		SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(ped, true);
		SET_PED_RELATIONSHIP_GROUP_HASH(ped, relationshipGroup);
		SET_PED_HEARING_RANGE(ped, 9999.0);

		bone = GET_PED_BONE_INDEX(ped, 0x796E);

		bomb = CREATE_OBJECT(bombHash, playerPos.x, playerPos.y + 2, playerPos.z, true, false, false);
		ATTACH_ENTITY_TO_ENTITY(bomb, ped, bone, 0.58, 0.0, 0.0, 90.0, -30.0, 90.0, true, false, false, false, 0, true);

		kamiBomb[ped] = bomb;

		TASK_FOLLOW_TO_OFFSET_OF_ENTITY(ped, playerPed, 0.0, 0.0, 0.0, 10.0, -1, 0.0, true);
		PLAY_PAIN(ped, 8, 0, 0);

		REQUEST_ANIM_DICT(animDict);
		while not HAS_ANIM_DICT_LOADED(animDict) do
			WAIT(0);
		end
		TASK_PLAY_ANIM(ped, animDict, "handsup_base", 8, 8, -1, 49, 0, false, false, false);
	end

	for kamikaze, _ in pairs(kamiBomb) do
		maxHealth = GET_ENTITY_MAX_HEALTH(kamikaze);

		playerVeh = GET_VEHICLE_PED_IS_IN(playerPed, false);

		if (maxHealth > 0 and (IS_PED_INJURED(kamikaze) or IS_PED_RAGDOLL(kamikaze) or IS_ENTITY_TOUCHING_ENTITY(kamikaze, playerPed) or IS_ENTITY_TOUCHING_ENTITY(kamikaze, playerVeh))) then
			kamikazePos = GET_ENTITY_COORDS(kamikaze, false);

			ADD_EXPLOSION(kamikazePos.x, kamikazePos.y, kamikazePos.z, 4, 9999.0, true, false, 1.0, false);

			SET_ENTITY_HEALTH(kamikaze, 0, false);
			SET_ENTITY_MAX_HEALTH(kamikaze, 0);
		end
	end
end
