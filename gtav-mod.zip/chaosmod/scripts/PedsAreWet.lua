ScriptInfo = {
    Name = "Everyone Is Wet",
    ScriptId = "peds_arewet",
    TimedType = "Normal",
}

function OnStop()
    for _, ped in ipairs(GetAllPeds()) do
        CLEAR_PED_WETNESS(ped)
    end
end

function OnTick()
    for _, ped in ipairs(GetAllPeds()) do
        SET_PED_WETNESS_ENABLED_THIS_FRAME(ped)
        SET_PED_WETNESS_HEIGHT(ped, 1.1)
    end
end