ScriptInfo = {
	Name = "Drama Queen",
	ScriptId = "peds_screamonshot",
	TimedType = "Normal", 
	IncompatibleIds = { 
		"player_noragdoll", 
		"player_ragdollondmg" 
	},
};

function OnStart()
	for _, ped in ipairs(GetAllPeds()) do
		CLEAR_ENTITY_LAST_DAMAGE_ENTITY(ped);
	end
end

function OnTick()
	playerPed = PLAYER_PED_ID();
	for _, ped in ipairs(GetAllPeds()) do
		if ped ~= playerPed then
			if HAS_ENTITY_BEEN_DAMAGED_BY_ANY_PED(ped) then
				SET_PED_TO_RAGDOLL(ped, 4000, 5000, 1, true, true, 0);
				CREATE_NM_MESSAGE(true, 0);
				GIVE_PED_NM_MESSAGE(ped);
				CREATE_NM_MESSAGE(true, 526);
				GIVE_PED_NM_MESSAGE(ped);

				CLEAR_ENTITY_LAST_DAMAGE_ENTITY(ped);

				SET_PED_VOICE_FULL(ped);
				PLAY_PAIN(ped, 8, 0.0, false);
			end
		end
	end
end