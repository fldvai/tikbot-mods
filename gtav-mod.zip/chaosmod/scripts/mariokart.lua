--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Mario Kart",
    ScriptId = "peds_kart",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("veto"), 120)
end
