ScriptInfo = {
    Name = "No-Clip",
    ScriptId = "player_airbreak",
    TimedType = "Short"
}

local lastTick = 0;
local speed = 0.04;

function OnStart()
    local plrPed = PLAYER_PED_ID();

    CLEAR_PED_TASKS_IMMEDIATELY(plrPed);

    local newPos = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plrPed, 0.0, 0.0, 1.0);
    SET_ENTITY_COORDS(plrPed, newPos.x, newPos.y, newPos.z, true, false, false, false);

    lastTick = GetTickCount();

    CLEAR_BRIEF();
    BEGIN_TEXT_COMMAND_DISPLAY_HELP("THREESTRINGS");
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("Press ~INPUT_MOVE_UP_ONLY~ ~INPUT_MOVE_LEFT_ONLY~ ~INPUT_MOVE_DOWN_ONLY~ ~INPUT_MOVE_RIGHT_ONLY~");
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("to move");
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~n~Press ~INPUT_VEH_MOVE_UP_ONLY~ ~INPUT_VEH_MOVE_DOWN_ONLY~ to move vertically");
    END_TEXT_COMMAND_DISPLAY_HELP(0, false, true, 10000);
end

function OnStop()
    local plrPed = PLAYER_PED_ID();

    SET_ENTITY_INVINCIBLE(plrPed, false);
    FREEZE_ENTITY_POSITION(plrPed, false);
    
    SET_PED_CAN_RAGDOLL(plrPed, true);
    SET_ENTITY_COLLISION(plrPed, true, true);
end

function OnTick()
    local plrPed = PLAYER_PED_ID();

    SET_ENTITY_INVINCIBLE(plrPed, true);
    FREEZE_ENTITY_POSITION(plrPed, true);

    SET_PED_CAN_RAGDOLL(plrPed, false);
    SET_ENTITY_COLLISION(plrPed, false, false);

    if GetTickCount() - lastTick >= 10 then
        lastTick = GetTickCount();
    
        if IS_CONTROL_PRESSED(0, 32) then
            local offVec = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plrPed, 0.0, 1.0, 0.0);
            SET_ENTITY_COORDS(plrPed, offVec.x, offVec.y, offVec.z-1.0, false, false, false, false);
        elseif IS_CONTROL_PRESSED(0, 33) then
            local offVec = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plrPed, 0.0, -1.0, 0.0);
            SET_ENTITY_COORDS(plrPed, offVec.x, offVec.y, offVec.z-1.0, false, false, false, false);
        end

        if IS_CONTROL_PRESSED(0, 34) then
            local offVec = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plrPed, 1.0, 0.0, 0.0);
            SET_ENTITY_COORDS(plrPed, offVec.x, offVec.y, offVec.z-1.0, false, false, false, false);
        elseif IS_CONTROL_PRESSED(0, 35) then
            local offVec = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plrPed, -1.0, 0.0, 0.0);
            SET_ENTITY_COORDS(plrPed, offVec.x, offVec.y, offVec.z-1.0, false, false, false, false);
        end

        if IS_CONTROL_PRESSED(0, 61) then
            local offVec = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plrPed, 0.0, 0.0, 1.0);
             SET_ENTITY_COORDS(plrPed, offVec.x, offVec.y, offVec.z-1.0, false, false, false, false);
         elseif IS_CONTROL_PRESSED(0, 62) then
             local offVec = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plrPed, 0.0, 0.0, -1.0);
             SET_ENTITY_COORDS(plrPed, offVec.x, offVec.y, offVec.z-1.0, false, false, false, false);
        end
    end
end