ScriptInfo = {
	Name = "Gun Game",
	ScriptId = "player_gun_game",
	TimedType = "Normal"
};

--Effect by ProfessorBiddle


function OnStart()
	playerKills = -1;
	--set to effectively infinite to prevent death on activation
	playerKillsLast = 2147483647;
	playerPed = PLAYER_PED_ID();
	REMOVE_ALL_PED_WEAPONS(playerPed, 0);
	GIVE_WEAPON_TO_PED(playerPed, GET_HASH_KEY("WEAPON_PISTOL"), 9999, false, true);
end

function OnTick()
	playerPed = PLAYER_PED_ID();

	playerType = GET_PED_TYPE(playerPed);
	--get correct character hash
	if playerType == 0 then -- PED_TYPE_PLAYER_0 
		hitHash = GET_HASH_KEY("SP0_KILLS");
	end
	if playerType == 1 then -- PED_TYPE_PLAYER_1
		hitHash = GET_HASH_KEY("SP1_KILLS");
	end
	if playerType == 3 then -- PED_TYPE_PLAYER_2
		hitHash = GET_HASH_KEY("SP2_KILLS");
	end
	--get stat for current character
	playerKills = Holder();
	STAT_GET_INT(hitHash, playerKills, -1);
	--check if stat this tick is larger than stat last tick
	if (playerKills:AsInteger() > playerKillsLast) then
		REMOVE_ALL_PED_WEAPONS(playerPed, 0);
		weps = GetAllWeapons();
		wepGive = weps[math.random(1, #weps)];
		--make sure it's actually a gun, not a broken bottle etc.
		while (GET_WEAPON_CLIP_SIZE(wepGive) < 2) do
			wepGive = weps[math.random(1, #weps)];
		end
		--player always has pistol because sometimes the other weapon doesn't work
		GIVE_WEAPON_TO_PED(playerPed, GET_HASH_KEY("WEAPON_PISTOL"), 9999, false, true);
		GIVE_WEAPON_TO_PED(playerPed, wepGive, 9999, false, true);
	end
	playerKillsLast = playerKills:AsInteger();
end