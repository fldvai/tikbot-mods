--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Attach All Enemies Together",
    ScriptId = "peds_attach_all_enemies",
    TimedType = "Normal"
};

function GetAllEnemies()
    local enemies = {}

    local player = PLAYER_PED_ID()

    for _, ped in ipairs(GetAllPeds()) do
        if GET_RELATIONSHIP_BETWEEN_PEDS(player, ped) >= 4 or GET_RELATIONSHIP_BETWEEN_PEDS(ped, player) >= 4 then
            table.insert(enemies, ped)
        end
    end

    return enemies
end

local enemies = {}
local mainEnemy = 0

function OnTick()
    local curEnemies = GetAllEnemies();

    local playerCoords = GET_ENTITY_COORDS(PLAYER_PED_ID());
    local enemyCoords  = GET_ENTITY_COORDS(mainEnemy);

    if mainEnemy == 0 or not DOES_ENTITY_EXIST(mainEnemy) or IS_ENTITY_DEAD(mainEnemy, 0) or
        GET_DISTANCE_BETWEEN_COORDS(playerCoords.x, playerCoords.y, playerCoords.z, enemyCoords.x, enemyCoords.y,
            enemyCoords.z, true) >= 50 then
        mainEnemy = 0;
        for _, enemy in ipairs(curEnemies) do
            enemyCoords = GET_ENTITY_COORDS(enemy);
            if IS_PED_HUMAN(enemy) and not IS_ENTITY_DEAD(enemy, 0) and
                (GET_DISTANCE_BETWEEN_COORDS(playerCoords.x, playerCoords.y, playerCoords.z, enemyCoords.x,
                    enemyCoords.y, enemyCoords.z, true) < 50 or mainEnemy == 0) then
                mainEnemy = enemy
            end
        end
        for _, enemy in ipairs(enemies) do
            if DOES_ENTITY_EXIST(enemy) then
                DETACH_ENTITY(enemy, true, false)
            end
        end
    end

    if mainEnemy ~= 0 then
        for _, enemy in ipairs(curEnemies) do
            enemies[enemy] = true

            if IS_PED_IN_ANY_VEHICLE(enemy, false) and enemy ~= mainEnemy then
                TASK_LEAVE_VEHICLE(enemy, GET_VEHICLE_PED_IS_IN(enemy, false), 16);
            end

            if enemy ~= mainEnemy and not IS_ENTITY_ATTACHED(enemy) and not IS_ENTITY_DEAD(enemy, 0) then
                ATTACH_ENTITY_TO_ENTITY(
                    enemy, mainEnemy, 0,
                    math.random() - 0.5, math.random() - 0.5, math.random() / 2,
                    math.random(360), math.random(360), math.random(360),
                    false, false, false, true, 0, true
                );
            end
        end
    end

    for enemy, _ in pairs(enemies) do
        if DOES_ENTITY_EXIST(enemy) and IS_ENTITY_DEAD(enemy, 0) then
            DETACH_ENTITY(enemy, true, false)
            enemies[enemy] = nil
        end
    end
end

function OnStop()
    for _, enemy in ipairs(enemies) do
        if DOES_ENTITY_EXIST(enemy) then
            DETACH_ENTITY(enemy, true, false)
        end
    end
    enemies = {}
end
