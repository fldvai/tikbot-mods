
--[[
 *	Effect by juhana
 --]]

ScriptInfo = {
	Name = "Vehicle Swap",
	ScriptId = "peds_vehicle_swap"
};


function OnStart()
	player = PLAYER_PED_ID();

	for _, ped in ipairs(GetAllPeds()) do
		if (ped ~= player) then
			currentVeh = GET_VEHICLE_PED_IS_IN(ped, false);
			closestVeh = -1;
			closestDist = 9999.0;
			pedPos = GET_ENTITY_COORDS(ped, false);

			for _, veh in ipairs(GetAllVehicles()) do
				if (veh ~= currentVeh) then
					coords = GET_ENTITY_COORDS(veh, false);
					dist = GET_DISTANCE_BETWEEN_COORDS(coords.x, coords.y, coords.z, pedPos.x, pedPos.y, pedPos.z, true);
					
					if (dist < closestDist) then
						closestVeh = veh;
						closestDist = dist;
					end
				end
			end

			if (closestVeh ~= -1) then
				TASK_ENTER_VEHICLE(ped, closestVeh, -1, -2, 2.0, 1, 0);
			end
		end
	end
end