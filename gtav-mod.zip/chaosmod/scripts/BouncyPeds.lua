--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Bouncy Peds",
    ScriptId = "peds_bouncy",
    TimedType = "Normal"
};

function OnTick()
    velFactor = 0
    player = PLAYER_PED_ID()
    for _, ped in ipairs(GetAllPeds()) do
        if ped ~= player then
            SET_ENTITY_INVINCIBLE(ped, true);
            if HAS_ENTITY_COLLIDED_WITH_ANYTHING(ped) then
                vel = GET_ENTITY_VELOCITY(ped);
                if (vel.x < 10) and (vel.y < 10) and (vel.z < 10) then
                    velFactor = 300.0;
                else
                    velFactor = 60.0;
                end
                APPLY_FORCE_TO_ENTITY(ped, 0, vel.x * -velFactor, vel.y * -velFactor, vel.z * -velFactor, 0.0, 0.0,
                    0.0, 0, 1, 1, 1, 0, 1);
            end
        end
    end
end

function OnStop()
    for _, ped in ipairs(GetAllPeds()) do
        if ped ~= player then
            SET_ENTITY_INVINCIBLE(ped, false);
        end
    end
end
