ScriptInfo = {
    Name = "Gun Control",
    ScriptId = "peds_noguns",
    TimedType = "Short"
}

local meleeWeapons = { 1637481976, 2578778090, 1737195953, 1317494643, 2508868239, 2227010557, 4192643659, 1141786504, 1703483498, 2460120199, 4191993645, 3713923289, 2343591895, 3756226112, 419712736, 2484171525, 3441901897, 940833800 }

local removedPedWeapons = {}

function IsWeaponMelee(weaponModel)
    for _, meleeModel in ipairs(meleeWeapons) do
        if weaponModel == meleeModel then
            return true;
        end
    end
    return false;
end 

function OnStop()
    --for ped, weapons in pairs(removedPedWeapons) do
        --for _, weapon in ipairs(weapons) do
            --GIVE_WEAPON_TO_PED(ped, weapon, 9999, false, true);
        --end
    --end

    removedPedWeapons = {};
end

function OnTick()
    for _, ped in ipairs(GetAllPeds()) do
        local pedCurWepHolder = Holder();
        GET_CURRENT_PED_WEAPON(ped, pedCurWepHolder, false);
        local weapon = pedCurWepHolder:AsInteger();
        if not IsWeaponMelee(weapon) then
            REMOVE_WEAPON_FROM_PED(ped, weapon);
            if removedPedWeapons[ped] == nil then
                removedPedWeapons[ped] = {};
            end
            table.insert(removedPedWeapons[ped], weapon);

            local nowWep = meleeWeapons[math.random(1, #meleeWeapons)];
            GIVE_WEAPON_TO_PED(ped, nowWep, 1, false, true);
            SET_CURRENT_PED_WEAPON(ped, nowWep, true);
        end
    end
end