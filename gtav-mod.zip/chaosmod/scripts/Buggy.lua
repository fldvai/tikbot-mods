ScriptInfo = {
    Name = "Ramp Buggy",
    ScriptId = "player_buggy",
}

function OnStart()
    local trainModel = GET_HASH_KEY("dune5");
    local carModel = GET_HASH_KEY("ruiner2");

    LoadModel(trainModel);
    LoadModel(carModel);
    local player = PLAYER_PED_ID();
    
    if not IS_PED_IN_ANY_VEHICLE(player, false) then
        local veh = GET_VEHICLE_PED_IS_USING(player);
        local spawnCoords = GET_ENTITY_COORDS(player, true);
        veh = CreatePoolVehicle(carModel, spawnCoords.x, spawnCoords.y, spawnCoords.z, GET_ENTITY_HEADING(player));
        SET_PED_INTO_VEHICLE(player, veh, -1);
    end

    local spawnCoords = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player, 12.0, 0.0, -0.5);
    local train = CreatePoolVehicle(trainModel, spawnCoords.x, spawnCoords.y, spawnCoords.z, GET_ENTITY_HEADING(player) + 90.0);
    ACTIVATE_PHYSICS(train);
	SET_ENTITY_HAS_GRAVITY(train, true);
    
	WAIT(150);
	local playerPos = GET_ENTITY_COORDS(player, true);
	local targetPos = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player, -25.0, 0.0, 0.0);
	SET_ENTITY_VELOCITY(train, targetPos.x - playerPos.x, targetPos.y - playerPos.y, targetPos.z - playerPos.z);
end