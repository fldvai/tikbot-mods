ScriptInfo = {
	Name = "Happy Birthday!",
	ScriptId = "player_birthday"
};

local ptfxDict = "core";
local ptfxName = "ent_dst_gen_gobstop";

function OnStart()
    REQUEST_SCRIPT_AUDIO_BANK("DLC_BATTLE/BTL_CLUB_DJ_CALLOUT_CROWD_CHEER", 0, -1);

    LoadModel(GET_HASH_KEY("s_m_y_clown_01"));
    LoadModel(GET_HASH_KEY("v_res_cakedome"));

    REQUEST_NAMED_PTFX_ASSET(ptfxDict);
    while not HAS_NAMED_PTFX_ASSET_LOADED(ptfxDict) do
        WAIT(0);
    end

    local playerPed = PLAYER_PED_ID();
    local playerGroup = GET_HASH_KEY("PLAYER");

    local relationshipGroupHolder = Holder();
    ADD_RELATIONSHIP_GROUP("_BRTHDAY_CLOWN", relationshipGroupHolder);
	local relationshipGroup = relationshipGroupHolder:AsInteger();
    SET_RELATIONSHIP_BETWEEN_GROUPS(0, relationshipGroup, playerGroup);
    SET_RELATIONSHIP_BETWEEN_GROUPS(0, playerGroup, relationshipGroup);

    local plrVeh = GET_VEHICLE_PED_IS_USING(playerPed);

    local plrPos = GET_ENTITY_COORDS(playerPed, not IS_ENTITY_DEAD(playerPed, true));

    local newPed = CreatePoolPed(4, GET_HASH_KEY("s_m_y_clown_01"), plrPos.x, plrPos.y, plrPos.z, 0.0);
    SET_PED_RELATIONSHIP_GROUP_HASH(newPed, relationshipGroup);
    SET_PED_AS_GROUP_MEMBER(newPed, GET_PLAYER_GROUP(PLAYER_ID()));
    if (DOES_ENTITY_EXIST(plrVeh)) then
        SET_PED_INTO_VEHICLE(newPed, plrVeh, -2);
    end

    local cake = CreatePoolProp(GET_HASH_KEY("v_res_cakedome"), 0.0, 0.0, 0.0, false);
    ATTACH_ENTITY_TO_ENTITY(cake, playerPed, GET_PED_BONE_INDEX(playerPed, 57005), 0.0, 0.0, 0.0, -90.0, 50.0, 0.0, true, true, false, true, 1, true);
    SET_ENTITY_COMPLETELY_DISABLE_COLLISION(cake, false, true);

    USE_PARTICLE_FX_ASSET(ptfxDict);
    START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE(ptfxName, playerPed, 0.0, 0.0, 0.2, 0.0, 0.0, 0.0, GET_PED_BONE_INDEX(playerPed, 0x796e), 1.5, false, false, false);

    PLAY_SOUND_FROM_ENTITY(0, "dj_crowd_cheer", playerPed, "dlc_btl_club_dj_callout_crowd_cheers_sounds", false, 0);

    RELEASE_NAMED_SCRIPT_AUDIO_BANK("DLC_BATTLE/BTL_CLUB_DJ_CALLOUT_CROWD_CHEER");
    REMOVE_NAMED_PTFX_ASSET(ptfxDict);
end