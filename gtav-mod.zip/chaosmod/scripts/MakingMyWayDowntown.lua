ScriptInfo = {
    Name = "Makin' My Way Downtown",
    ScriptId = "vehs_spawn_piano",
	EffectGroup = "_group_spawngeneric",
};

function OnStart()
	carModel = 0x1BB290BC;
	pianoModel = 0xC0217799;
    REQUEST_MODEL(carModel);
    REQUEST_MODEL(pianoModel);

    player = PLAYER_PED_ID();
	playerPos = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player, 0.0, 2.0, 0.0);

	veh = CreatePoolVehicle(carModel, playerPos.x, playerPos.y, playerPos.z, GET_ENTITY_HEADING(player));
	SET_VEHICLE_ENGINE_ON(veh, true, true, false);
	SET_VEHICLE_MOD_KIT(veh, 0);
	SET_ENTITY_ALPHA(veh, 0, false);
	SET_ENTITY_VISIBLE(veh, false, false);

	piano = CreatePoolProp(pianoModel, playerPos.x, playerPos.y + 2.0, playerPos.z, true);
	ATTACH_ENTITY_TO_ENTITY(piano, veh, 0, 0.0, 1.3, -0.7, 0.0, 0.0, 0.0, true, false, false, false, 0, true);
end