--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Bouncy Player",
    ScriptId = "player_bouncy",
    TimedType = "Normal"
};

function OnTick()
    velFactor = 0
    player = PLAYER_PED_ID()
    SET_ENTITY_INVINCIBLE(player, true);
    if HAS_ENTITY_COLLIDED_WITH_ANYTHING(player) then
        vel = GET_ENTITY_VELOCITY(player);
        if (vel.x < 10) and (vel.y < 10) and (vel.z < 10) then
            velFactor = 300.0;
        else
            velFactor = 60.0;
        end
        APPLY_FORCE_TO_ENTITY(player, 0, vel.x * -velFactor, vel.y * -velFactor, vel.z * -velFactor, 0.0, 0.0,
            0.0, 0, 1, 1, 1, 0, 1);
    end
end

function OnStop()
    SET_ENTITY_INVINCIBLE(PLAYER_PED_ID(), false);
end
