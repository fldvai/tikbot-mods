--[[
    Effect By OnlyRealNubs
--]]

ScriptInfo = {
	Name = "Get Slapped",
	ScriptId = "misc_get_slapped"
};

slapperHash = GET_HASH_KEY("ig_brucie2");

dict = "melee@unarmed@streamed_variations";
slap = "plyr_takedown_front_slap";
slapped = "victim_takedown_front_slap";

function LoadAssets()
    REQUEST_ANIM_DICT(dict);
    while not HAS_ANIM_DICT_LOADED(dict) do
        WAIT(0);
    end

    REQUEST_MODEL(slapperHash);
    while not HAS_MODEL_LOADED(slapperHash) do
        WAIT(0);
    end
end

-- ped2 will slap ped1
function EmoteTwoPeds(ped1, ped2)
    coords = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped1, 0.0, 1.0, 0.0);
    heading = GET_ENTITY_HEADING(ped1);

    SET_ENTITY_COORDS(ped2, coords.x, coords.y, coords.z, false, false, false, false);
    SET_ENTITY_HEADING(ped2, heading - 180.10);

    WAIT(300);
    SET_CURRENT_PED_WEAPON(ped1, GET_HASH_KEY("WEAPON_UNARMED"), true);
    SET_CURRENT_PED_WEAPON(ped2, GET_HASH_KEY("WEAPON_UNARMED"), true);

    TASK_PLAY_ANIM(ped2, dict, slap, 2.0, 2.0, 2000, 51, 0.0, false, false, false);
    TASK_PLAY_ANIM(ped1, dict, slapped, 2.0, 2.0, 2000, 0, 0.0, false, false, false);
    WAIT(1800);
end

function OnStart()
    LoadAssets();

    player = PLAYER_PED_ID();

    SET_PLAYER_CONTROL(PLAYER_ID(), false, 1 << 8);
    slapper = CreatePoolPed(4, slapperHash, 0.0, 0.0, 0.0, 0.0);

    
    EmoteTwoPeds(player, slapper);
    TASK_WANDER_STANDARD(slapper, 10.0, 10);
    SET_PED_TO_RAGDOLL(player, 1200, 1200, 0, false, false, false);
    SET_ENTITY_AS_NO_LONGER_NEEDED(Holder(slapper));
    SET_PLAYER_CONTROL(PLAYER_ID(), true, 1 << 8);
end