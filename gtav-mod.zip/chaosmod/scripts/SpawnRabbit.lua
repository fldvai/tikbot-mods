ScriptInfo = {
    Name = "Spawn Companion Rabbit",
    ScriptId = "giant_rabbit",
}

function OnStart()
	local modelHash = GET_HASH_KEY("a_c_rabbit_02");

	local relationshipGroup = Holder();
	ADD_RELATIONSHIP_GROUP("_COMPANION_RABBIT", relationshipGroup);
	SET_RELATIONSHIP_BETWEEN_GROUPS(0, relationshipGroup:AsInteger(), GET_HASH_KEY("PLAYER"));
	SET_RELATIONSHIP_BETWEEN_GROUPS(0, GET_HASH_KEY("PLAYER"), relationshipGroup:AsInteger());

	local playerPed = PLAYER_PED_ID();
	local playerPos = GET_ENTITY_COORDS(playerPed, false);

	local ped = CreatePoolPed(28, modelHash, playerPos.x, playerPos.y, playerPos.z, GET_ENTITY_HEADING(playerPed));
	if IS_PED_IN_ANY_VEHICLE(playerPed, false) then
		SET_PED_INTO_VEHICLE(ped, GET_VEHICLE_PED_IS_IN(playerPed, false), -2);
    end

	SET_PED_COMBAT_ABILITY(ped, 100);
	SET_PED_SUFFERS_CRITICAL_HITS(ped, false);

	SET_PED_RELATIONSHIP_GROUP_HASH(ped, relationshipGroup:AsInteger());
	SET_PED_HEARING_RANGE(ped, 9999.0);

	SET_PED_AS_GROUP_MEMBER(ped, GET_PLAYER_GROUP(PLAYER_ID()));

	SET_PED_COMBAT_ATTRIBUTES(ped, 5, true);
	SET_PED_COMBAT_ATTRIBUTES(ped, 46, true);

	SET_PED_ACCURACY(ped, 100);
	SET_PED_FIRING_PATTERN(ped, 0xC6EE6B4C);

	GIVE_WEAPON_TO_PED(ped, GET_HASH_KEY("WEAPON_ASSAULTRIFLE"), 9999, false, true);
end