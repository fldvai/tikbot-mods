--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Spiderman",
    ScriptId = "player_spiderman",
    TimedType = "Normal"
}

function GetForwardCoords(coords, forwardv, distance)
    return Vector3(
        coords.x + forwardv.x * distance,
        coords.y + forwardv.y * distance,
        coords.z + forwardv.z * distance
    )
end

function GetPlayerForwardCoords(player, distance)
    return GetForwardCoords(GET_ENTITY_COORDS(player, false), GET_ENTITY_FORWARD_VECTOR(player), distance)
end

function GetWallNormalAndPoint(coords, forwardv, forwardDistance, backwardDistance)

    local forwardCoords = GetForwardCoords(coords, forwardv, forwardDistance)
    local backwardCoords = GetForwardCoords(coords, Vector3(-forwardv.x, -forwardv.y, -forwardv.z), backwardDistance)

    local shapeTestHandle = START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE(
        backwardCoords.x, backwardCoords.y, backwardCoords.z,
        forwardCoords.x, forwardCoords.y, forwardCoords.z,
        1, player, 4
    )

    if shapeTestHandle ~= 0 then
        hit, endCoords, surfaceNormal, entityHit = Holder(), Holder(), Holder(), Holder()
        if GET_SHAPE_TEST_RESULT(shapeTestHandle, hit, endCoords, surfaceNormal, entityHit) == 2 then
            if hit:AsBoolean() then
                return surfaceNormal:AsVector3(), endCoords:AsVector3()
            end
        end
    end

    return nil, nil
end

function TestPlayerCanStartClimbing()
    local player = PLAYER_PED_ID()
    local coords = GET_ENTITY_COORDS(player)

    local normal, point = GetWallNormalAndPoint(coords, GET_ENTITY_FORWARD_VECTOR(player), 1.0, 0.0)

    return normal ~= nil and point ~= nil
end

function TestPlayerReachedTop(coords, forwardv)
    local normal, point = GetWallNormalAndPoint(Vector3(coords.x, coords.y, coords.z + 1),
        forwardv, 2.0, 2.0)

    return normal == nil or point == nil
end

function TestPlayerReachedGround(coords, height)
    local groundz = Holder()
    GET_GROUND_Z_FOR_3D_COORD(coords.x, coords.y, coords.z, groundz, false, false)
    return groundz:AsFloat() == 0.0 or coords.z - groundz:AsFloat() < height
end

function GetPlayerWidth(player)
    local min, max = Holder(), Holder()
    GET_MODEL_DIMENSIONS(GET_ENTITY_MODEL(player), min, max)

    return (max:AsVector3()).y - (min:AsVector3()).y
end

function DisplayHint()
    if IS_HELP_MESSAGE_BEING_DISPLAYED() then
        CLEAR_HELP(1)
    end
    BEGIN_TEXT_COMMAND_DISPLAY_HELP("STRING")
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("Press ~INPUT_JUMP~ to start climbing")
    END_TEXT_COMMAND_DISPLAY_HELP(0, 0, 1, -1)
end

function StopTasks()
    local player = PLAYER_PED_ID()
    CLEAR_PED_TASKS_IMMEDIATELY(player)
    CLEAR_HELP(1)
end

climbing = false
wasClimbing = false
exiting = false
coords = Vector3()
forwardv = Vector3()
direction = 1
total_anim_time = -1.0
cur_anim_time = 0.0

function OnStart()
    REQUEST_ANIM_DICT('laddersbase')
    REQUEST_ANIM_DICT('move_climb')
    while not HAS_ANIM_DICT_LOADED('laddersbase') or not HAS_ANIM_DICT_LOADED('move_climb') do
        WAIT(100)
    end
    total_anim_time = GET_ANIM_DURATION('laddersbase', 'climb_up')
end

function OnTick()
    local player = PLAYER_PED_ID()

    if not exiting then
        if not climbing then
            local cs = GET_ENTITY_COORDS(player, false)
            local fv = GET_ENTITY_FORWARD_VECTOR(player)
            if not IS_PED_CLIMBING(player) and TestPlayerCanStartClimbing() then
                DisplayHint()
                if IS_CONTROL_JUST_PRESSED(0, 22) then
                    climbing = true
                    wasClimbing = false
                    coords = cs
                    forwardv = fv
                    StopTasks()
                end
            elseif not TestPlayerReachedGround(Vector3(cs.x + fv.x * 2, cs.y + fv.y * 2, cs.z), 5) then
                normal, point = GetWallNormalAndPoint(Vector3(cs.x, cs.y, cs.z - 1), fv,
                    -2.0, -2.0)
                if normal ~= nil and point ~= nil then
                    DisplayHint()
                    if IS_CONTROL_JUST_PRESSED(0, 22) then
                        climbing = true
                        wasClimbing = false
                        coords = Vector3(point.x, point.y, point.z - 1)
                        forwardv = Vector3(-normal.x, -normal.y, -normal.z)
                        StopTasks()
                    end
                end
            else
                CLEAR_HELP(1)
            end
        end
        if climbing then

            local deltatime = GET_FRAME_TIME()
            local speed = 1.0

            if IS_CONTROL_PRESSED(0, 32) then -- up
                speed = 2.0
                deltatime = deltatime * speed
                coords.z = coords.z + deltatime
                if total_anim_time > 0.0 then
                    cur_anim_time = cur_anim_time + deltatime / total_anim_time
                    if cur_anim_time > 1.0 then
                        cur_anim_time = cur_anim_time - 1.0
                    end
                end
                direction = 1
            elseif IS_CONTROL_PRESSED(0, 33) then -- down
                speed = 1.7
                deltatime = deltatime * speed
                coords.z = coords.z - deltatime
                wasClimbing = true
                if total_anim_time > 0.0 then
                    cur_anim_time = cur_anim_time - deltatime / total_anim_time
                    if cur_anim_time < 0.0 then
                        cur_anim_time = cur_anim_time + 1.0
                    end
                end
                direction = -1
            else
                speed = 0.01
            end

            if IS_CONTROL_PRESSED(0, 34) then -- left
                coords.x = coords.x - deltatime * forwardv.y
                coords.y = coords.y + deltatime * forwardv.x
            elseif IS_CONTROL_PRESSED(0, 35) then -- right
                coords.x = coords.x + deltatime * forwardv.y
                coords.y = coords.y - deltatime * forwardv.x
            end

            if TestPlayerReachedGround(coords, 1.2) and wasClimbing then
                climbing = false
                StopTasks()
            elseif TestPlayerReachedTop(coords, forwardv) then
                exiting = true
                cur_anim_time = 0.0
            else
                local normal, point = GetWallNormalAndPoint(coords, forwardv, 2.5, 2.5)
                if normal ~= nil and point ~= nil then
                    forwardv = Vector3(-normal.x, -normal.y, -normal.z)
                    local width = GetPlayerWidth(player)
                    coords.x, coords.y = point.x - forwardv.x * width / 2, point.y - forwardv.y * width / 2

                    SET_ENTITY_COORDS_NO_OFFSET(player, coords.x, coords.y, coords.z, true, false, false, true)
                    SET_ENTITY_HEADING(player, GET_HEADING_FROM_VECTOR_2D(forwardv.x, forwardv.y))

                    TASK_PLAY_ANIM(
                        player, 'laddersbase',
                        direction > 0 and 'climb_up' or 'climb_down',
                        8.0, 1.0, -1, 1,
                        direction > 0 and cur_anim_time or 1 - cur_anim_time, false, false, false
                    )

                    SET_ENTITY_ANIM_SPEED(
                        player, 'laddersbase',
                        direction > 0 and 'climb_up' or 'climb_down',
                        speed
                    )
                else
                    climbing = false
                    StopTasks()
                end
            end
        end
    else
        local deltatime = GET_FRAME_TIME()

        dur = GET_ANIM_DURATION('move_climb', 'standclimbup_140_high')
        if dur > 0 then
            cur_anim_time = cur_anim_time + deltatime / dur
        else
            cur_anim_time = 1.0
        end

        coords.z = coords.z + dur * deltatime

        if cur_anim_time > 0.6 then
            coords.x = coords.x + forwardv.x * dur * deltatime * 0.5
            coords.y = coords.y + forwardv.y * dur * deltatime * 0.5
        end

        SET_ENTITY_COORDS_NO_OFFSET(player, coords.x, coords.y, coords.z, true, false, false, true)
        SET_ENTITY_HEADING(player, GET_HEADING_FROM_VECTOR_2D(forwardv.x, forwardv.y))
        TASK_PLAY_ANIM(player, 'move_climb', 'standclimbup_140_high', 8.0, 2.0, -1, 0, cur_anim_time, false, false, false)

        if cur_anim_time >= 1.0 then
            climbing = false
            exiting = false
        end
    end
end

function OnStop()
    climbing = false
    wasClimbing = false
    exiting = false
    coords = Vector3()
    forwardv = Vector3()
    direction = 1
    total_anim_time = -1.0
    cur_anim_time = 0.0
    local player = PLAYER_PED_ID()
    STOP_ANIM_TASK(player, 'laddersbase', 'climb_up', 0.0)
    STOP_ANIM_TASK(player, 'laddersbase', 'climb_down', 0.0)
    STOP_ANIM_TASK(player, 'move_climb', 'standclimbup_140_high', 0.0)
end
