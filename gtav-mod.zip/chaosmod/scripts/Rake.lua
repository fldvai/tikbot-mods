ScriptInfo = {
    Name = "Spawn Rake",
    ScriptId = "spawn_rake"
};

function OnStart()
    local playerPos = GET_ENTITY_COORDS(PLAYER_PED_ID(), true);
	CreatePoolVehicle(GET_HASH_KEY("RAKETRAILER"), playerPos.x, playerPos.y, playerPos.z, GET_ENTITY_HEADING(PLAYER_PED_ID()));
end