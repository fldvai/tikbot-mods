--[[
	Effect by casperge
--]]

ScriptInfo = {
	Name = "Where We Droppin?",
	ScriptId = "player_battle_bus",
	TimedType = "Normal"
};

function LoadModel(ulModel)
	if IS_MODEL_VALID(ulModel) then
		REQUEST_MODEL(ulModel);
		while not HAS_MODEL_LOADED(ulModel) do
			WAIT(0);
		end
	end
end

leaveTimer = -1;
function OnStart()
	bus = GET_HASH_KEY("bus");
	LoadModel(bus);
	veh = CREATE_VEHICLE(bus, -418.045, -1227.783, 484.594, 341.00, true, false, false);
	busMaxSeats = GET_VEHICLE_MODEL_NUMBER_OF_SEATS(bus);
	SET_VEHICLE_GRAVITY(veh, false);
	player = PLAYER_PED_ID();
	SET_PED_INTO_VEHICLE(player, veh, 0);
	SET_VEHICLE_FORWARD_SPEED(veh, 40);
	parachuteHash = GET_HASH_KEY("GADGET_PARACHUTE");
	GIVE_WEAPON_TO_PED(player, parachuteHash, 1, true, false);
	for _, ped in ipairs(GetAllPeds()) do
		if not IS_PED_A_PLAYER(ped) then
			if (ARE_ANY_VEHICLE_SEATS_FREE(veh)) then
				for i = -1, busMaxSeats - 1 do
					if (IS_VEHICLE_SEAT_FREE(veh, i, false)) then
						SET_PED_INTO_VEHICLE(ped, veh, i);
						break;
					end
				end
			end
		end
	end
end

function OnStop()
	SET_VEHICLE_GRAVITY(veh, true);
end

function OnTick()
	SET_VEHICLE_FORWARD_SPEED(veh, 55.0);
	vehPeds = {};
	for i = -1, busMaxSeats - 1 do
		if (not IS_VEHICLE_SEAT_FREE(veh, i, false)) then
			ped = GET_PED_IN_VEHICLE_SEAT(veh, i, false);
			table.insert(vehPeds, ped);
		end
	end
	current_time = GET_GAME_TIMER();

	if (#vehPeds > 0) then
		if (current_time > leaveTimer + 3500) then
			leaveTimer = current_time;
			randomped = vehPeds[math.random(1,  #vehPeds)];
			if not IS_PED_A_PLAYER(randomped) then
				TASK_LEAVE_VEHICLE(randomped, veh, 4160);
			end
		end
	end
end