--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Submersible",
    ScriptId = "peds_sub",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("submersible2"), 120)
end
