--[[
	Effect by Vladimir Gotsin
--]]


function OnStart()
	--vehicle
	playerPed = PLAYER_PED_ID();
	playerHeading = GET_ENTITY_HEADING(playerPed);
	heading = GET_ENTITY_HEADING(IS_PED_IN_ANY_VEHICLE(playerPed, false) and GET_VEHICLE_PED_IS_IN(playerPed, false) or playerPed);

	playerPos = GET_ENTITY_COORDS(playerPed, false);

	caddyModel = GET_HASH_KEY("CADDY");

	veh = CreatePoolVehicle(caddyModel, playerPos.x, playerPos.y, playerPos.z, heading);
	WAIT(0);

	--setting player into new vehicle
	SET_PED_INTO_VEHICLE(playerPed, veh, -1);

	--clothes
	pedType = GET_PED_TYPE(playerPed);

	if (pedType == 0) then
		--Michael
		SET_PED_COMPONENT_VARIATION(playerPed, 0, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 1, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 2, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 3, 16, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 4, 15, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 5, 3, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 6, 1, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 7, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 8, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 9, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 10, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 11, 0, 0, 0);

		SET_PED_PROP_INDEX(playerPed, 0, 8, 0, false);
	elseif (pedType == 1) then
		--Franklin
		SET_PED_COMPONENT_VARIATION(playerPed, 0, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 1, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 2, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 3, 6, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 4, 6, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 5, 2, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 6, 5, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 7, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 8, 14, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 9, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 10, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 11, 8, 0, 0);
	elseif (pedType == 3) then
		--Trevor
		SET_PED_COMPONENT_VARIATION(playerPed, 0, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 1, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 2, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 3, 11, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 4, 11, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 5, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 6, 1, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 7, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 8, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 9, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 10, 0, 0, 0);
		SET_PED_COMPONENT_VARIATION(playerPed, 11, 0, 0, 0);
	end

	--weapon
	--REMOVE_ALL_PED_WEAPONS(playerPed, false);
	weaponHash = GET_HASH_KEY("WEAPON_GOLFCLUB");
	GIVE_WEAPON_TO_PED(playerPed, weaponHash, 1, false, true);
end

ScriptInfo = {
	Name = "Golf%",
	ScriptId = "player_golf_percent"
};