ScriptInfo = {
    Name = "Warzone",
    ScriptId = "misc_warzone",
    TimedType = "Short"
};

local weapons = { "WEAPON_PISTOL", "WEAPON_STUNGUN", "WEAPON_SMG", "WEAPON_PUMPSHOTGUN", "WEAPON_ASSAULTSHOTGUN", "WEAPON_ASSAULTRIFLE", "WEAPON_COMBATMG" };
local lastTick;

function math.randomf(min,  max)
    return math.random(min*10, max*10)/10;
end

function OnStart()
    for _, wep in ipairs(weapons) do
        REQUEST_WEAPON_ASSET(GET_HASH_KEY(wep), 31, 0)
    end

    lastTick = GetTickCount();
end

function OnTick()
    local curTick = GetTickCount();

    if curTick - lastTick >= 100 then
		lastTick = curTick;

        local plr = PLAYER_PED_ID();
        local fromMax = 10.0;
        local fromMin = -10.0;
    
        local fromZMax = 4.0;
        local fromZMin = -0.3;
        local fromOffset = Vector3(math.randomf(fromMin, fromMax), math.randomf(fromMin, fromMax), math.randomf(fromZMin, fromZMax));
        local from = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plr, fromOffset.x, fromOffset.y, fromOffset.z);
    

        local toXMin = (function() if from.x > 0 then return fromMin else return 0 end end)();
        local toXMax = (function() if from.x > 0 then return 0 else return fromMax end end)();

        local toYMin = (function() if from.y > 0 then return fromMin else return 0 end end)();
        local toYMax = (function() if from.y > 0 then return 0 else return fromMax end end)();

        local toZMin = (function() if from.z > 0 then return fromZMin else return 0 end end)();
        local toZMax = (function() if from.z > 0 then return 0 else return fromZMax end end)();

        local toOffset = Vector3(math.randomf(toXMin, toXMax), math.randomf(toYMin, toYMax), math.randomf(toZMin, toZMax));

        local to = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plr, toOffset.x, toOffset.y, toOffset.z);

		local weapon = GET_HASH_KEY(weapons[math.random(1, #weapons)]);
		SHOOT_SINGLE_BULLET_BETWEEN_COORDS(from.x, from.y, from.z, to.x, to.y, to.z, math.floor(GET_WEAPON_DAMAGE(weapon, 0) * 0.6), false, weapon, 0, true, true, -1.0);
    end
end