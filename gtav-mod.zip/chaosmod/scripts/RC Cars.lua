--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "RC Cars",
    ScriptId = "peds_rcbandito",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("rcbandito"), 120)
end
