ScriptInfo = {
    Name = "Water Guns",
    ScriptId = "weps_water",
    TimedType = "Normal",
    IncompatibleIds = {
        "misc_flamethrower",
    },
};

local MAX_DURATION_BETWEEN_SHOTS = 5;
local MAX_DURATION_ANIMATION = 150;

local animationHandleByPed = {};

function OnStop()
    REMOVE_NAMED_PTFX_ASSET("core");
end

function OnTick()
    REQUEST_NAMED_PTFX_ASSET("core");
    while not HAS_NAMED_PTFX_ASSET_LOADED("core") do
        WAIT(0);
    end

    local firingPeds = {};

    for _, ped in ipairs(GetAllPeds()) do
        if IS_PED_SHOOTING(ped) then
            local weapon = GET_SELECTED_PED_WEAPON(ped);
            if GET_WEAPON_DAMAGE_TYPE(weapon) == 3 then
                firingPeds[#firingPeds+1] = ped;
            end
        end
    end

    local delayRemovePeds = 25;
    for ped, info in pairs(animationHandleByPed) do

        local animationInfo = info;
        if not DOES_ENTITY_EXIST(ped) or animationInfo.fxHandle <= 0 or animationInfo.fullDuration > MAX_DURATION_ANIMATION or ((not IS_PED_SHOOTING(ped) and IS_PED_WEAPON_READY_TO_SHOOT(ped)) and animationInfo.durationSinceLastShot > MAX_DURATION_BETWEEN_SHOTS) or (IS_PED_RELOADING(ped)) then
            STOP_PARTICLE_FX_LOOPED(animationInfo.fxHandle, false);
            animationHandleByPed[ped] = nil;
        else
            animationHandleByPed[ped].fullDuration = animationHandleByPed[ped].fullDuration + 1.0;
            animationHandleByPed[ped].durationSinceLastShot = animationHandleByPed[ped].durationSinceLastShot + 1.0;
        end
        if delayRemovePeds-1 == 0 then
            delayRemovePeds = 25;
            WAIT(0);
        end
    end

    local delayAnimationStart = 25;
    for _, ped in ipairs(firingPeds) do 
        if animationHandleByPed[ped] == nil then
            USE_PARTICLE_FX_ASSET("core");
            local weapon = GET_CURRENT_PED_WEAPON_ENTITY_INDEX(ped, 1);
            local handle = START_PARTICLE_FX_LOOPED_ON_ENTITY("water_cannon_jet", weapon, 0.6, 0.0, 0.0, 0.0, 0.0, -90.0, 2.0, false, false, false);
            local animInfo = {};
            animInfo.fxHandle = handle;
            animInfo.durationSinceLastShot = 0;
            animInfo.fullDuration = 0;
            animationHandleByPed[ped] = animInfo;
        else
            animationHandleByPed[ped].durationSinceLastShot = 0;
        end
        if delayAnimationStart-1 == 0 then
            delayAnimationStart = 25;
            WAIT(0);
        end
    end
end