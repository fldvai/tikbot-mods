ScriptInfo = {
    Name = "Roll Intro",
    ScriptId = "play_rstar_logo"
};

function OnStart()
    EnableScriptThreadBlock();

    local bink = SET_BINK_MOVIE("rockstar_logos");
    PLAY_BINK_MOVIE(bink);
    SET_BINK_SHOULD_SKIP(bink, false);
    SET_BINK_MOVIE_AUDIO_FRONTEND(bink, true);
    SET_BINK_MOVIE_VOLUME(bink, 100.0)
    SET_BINK_MOVIE_TIME(bink, 0.0);

    SET_PLAYER_CONTROL(PLAYER_ID(), false, 1 << 2)
    while GET_BINK_MOVIE_TIME(bink) < 100.0 do
        SET_SCRIPT_GFX_DRAW_ORDER(4);
        SET_SCRIPT_GFX_DRAW_BEHIND_PAUSEMENU(1);
        PLAY_BINK_MOVIE(bink);
        DRAW_BINK_MOVIE(bink, 0.5, 0.5, 1.0, 1.0, 0.0, 255, 255, 255, 255);
        WAIT(0);
    end
    SET_PLAYER_CONTROL(PLAYER_ID(), true, 1 << 2)

    STOP_BINK_MOVIE(bink);
    RELEASE_BINK_MOVIE(bink);

    DisableScriptThreadBlock();
end