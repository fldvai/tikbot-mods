--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Monster Jam",
    ScriptId = "peds_monster",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("marshall"), 120)
end
