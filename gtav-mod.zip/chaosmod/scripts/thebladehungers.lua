ScriptInfo = {
    Name = "The Blade Hungers",
    ScriptId = "misc_bladehungers",
    TimedType = "Normal"
}

local lastPlayerKills, fade, alpha, orange, bladeHash, lastTick

function OnStart()
	lastPlayerKills = -1
	bladeHash = GET_HASH_KEY("WEAPON_MACHETE")
	fade = 0
	alpha = 0
	orange = 0
	lastTick = 0
end

function OnTick()
	player = PLAYER_ID()
	SET_PLAYER_WANTED_LEVEL(player, 0, false)
	SET_PLAYER_WANTED_LEVEL_NOW(player, 0)

	playerPed = PLAYER_PED_ID()

	GIVE_WEAPON_TO_PED(playerPed, bladeHash, 1, false, true)

	playerHash = GET_ENTITY_MODEL(playerPed)
	allPlayerKills = 0
	killsList = { GET_HASH_KEY("SP0_KILLS"), GET_HASH_KEY("SP1_KILLS"), GET_HASH_KEY("SP2_KILLS") }
	for _, hash in ipairs(killsList) do
		curKills = Holder()
		STAT_GET_INT(hash, curKills, -1)
		allPlayerKills = allPlayerKills + curKills:AsInteger()
	end

	-- check if stat this tick is larger than stat last tick
	if lastPlayerKills >= 0 and allPlayerKills > lastPlayerKills then
		fade  = 0
		alpha = 0
    end
	lastPlayerKills = allPlayerKills

	orange = orange + GET_RANDOM_INT_IN_RANGE(-4, 10)
	alpha = alpha + GET_RANDOM_INT_IN_RANGE(-4, 10)

	curTick = GET_GAME_TIMER()
	if curTick > lastTick + 150 then
		lastTick = curTick
		fade = fade + 1
		alpha = alpha + 1
    end

	DRAW_RECT(0.5, 0.5, 1.0, 1.0, fade, orange, 0, 50, 0)

	if fade > 255 then
		START_ENTITY_FIRE(playerPed)
		SET_ENTITY_HEALTH(playerPed, 0, 0)
		fade = 0
		alpha = 0
		orange = 0
	elseif alpha > 100 then
		alpha = alpha - 20
	elseif orange > 30 then
		orange = orange - 20
	end
end
