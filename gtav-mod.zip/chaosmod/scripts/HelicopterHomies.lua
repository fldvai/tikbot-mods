--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Helicopter Homies",
    ScriptId = "peds_helicopterhomies",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("buzzard"), 120)
end
