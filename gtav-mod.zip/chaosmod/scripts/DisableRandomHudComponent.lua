
--[[
    Effect By OnlyRealNubs
--]]

ScriptInfo = {
	Name = "Disable Random Hud Component",
	ScriptId = "player_random_hud",
    TimedType = "Normal"
};

selectedComponent = 0;

availableComponents = {1, 2, 3, 6, 7, 8, 9, 10, 14, 15, 16, 19, 20, 22};

function OnStart()
    selectedComponent = availableComponents[math.random(1, #availableComponents)];
end

function OnTick()
    HIDE_HUD_COMPONENT_THIS_FRAME(selectedComponent);
end