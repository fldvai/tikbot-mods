--[[
	Effect by Gorakh
--]]

ScriptInfo = {
	Name = "Clown Cars",
	ScriptId = "vehs_clown_cars",
	TimedType = "Normal"
};

function LoadModel(ulModel)
	if IS_MODEL_VALID(ulModel) then
		REQUEST_MODEL(ulModel);
		while not HAS_MODEL_LOADED(ulModel) do
			WAIT(0);
		end
	end
end

function FindFreeSeat(veh)
	freeSeats = {};

	numSeats = GET_VEHICLE_MODEL_NUMBER_OF_SEATS(GET_ENTITY_MODEL(veh));
	for i = -1, numSeats do
		if (IS_VEHICLE_SEAT_FREE(veh, i, false) and GET_SEAT_PED_IS_TRYING_TO_ENTER(PLAYER_PED_ID()) ~= i) then
			table.insert(freeSeats, i);
		end
	end

	if (#freeSeats == 0) then
		return -3;
	end

	return freeSeats[math.random(1, #freeSeats)];
end

clowns = {};
nextClownSpawnTick = 0;

function OnTick()
	if (nextClownSpawnTick < GET_GAME_TIMER()) then
		vehicleToSpawnIn = -1;
		seatIndexToSpawnIn = -2;

		player = PLAYER_PED_ID();
		if (DOES_ENTITY_EXIST(player)) then
			if (IS_PED_IN_ANY_VEHICLE(player, false)) then
				playerVeh = GET_VEHICLE_PED_IS_IN(player, false);

				seatIndex = FindFreeSeat(playerVeh);
				if (seatIndex ~= -3) then
					vehicleToSpawnIn = playerVeh;
					seatIndexToSpawnIn = seatIndex;
				end
			end

			if (vehicleToSpawnIn == -1) then -- If player is not in a vehicle, or the player's vehicle doesn't have a free seat then
				playerCoords = GET_ENTITY_COORDS(player, 0);

				closestVehicle = -1;
				closestVehicleSeatIndex = -2;
				closestVehicleDistance = 9999999999999999999;
				for _, veh in ipairs(GetAllVehicles()) do
					vehCoords = GET_ENTITY_COORDS(veh, 0);

					distance = VDIST2(playerCoords.x, playerCoords.y, playerCoords.z, vehCoords.x, vehCoords.y, vehCoords.z);
					if (distance <= (60 * 60)) then -- Distance is squared then
						if (closestVehicle == -1 or distance < closestVehicleDistance) then
							seatIndex = FindFreeSeat(veh);
							if (seatIndex ~= -3) then
								closestVehicle = veh;
								closestVehicleSeatIndex = seatIndex;
								closestVehicleDistance = distance;
							end
						end
					end
				end

				if (closestVehicle ~= -1) then
					vehicleToSpawnIn = closestVehicle;
					seatIndexToSpawnIn = closestVehicleSeatIndex;
				end
			end
		end

		if (vehicleToSpawnIn ~= -1) then
			modelHash = GET_HASH_KEY("s_m_y_clown_01");
			LoadModel(modelHash);

			clown = CREATE_PED_INSIDE_VEHICLE(vehicleToSpawnIn, -1, modelHash, seatIndexToSpawnIn, true, false);

			TASK_LEAVE_VEHICLE(clown, vehicleToSpawnIn, 4160);

			table.insert(clowns, clown);

			copy = clown;
			SET_PED_AS_NO_LONGER_NEEDED(Holder(copy));

			nextClownSpawnTick = GET_GAME_TIMER() + math.random(900, 1800);
		end
	end

	player = PLAYER_PED_ID();
	if (DOES_ENTITY_EXIST(player)) then
		for it, clown in ipairs(clowns) do
			if (DOES_ENTITY_EXIST(clown) and not IS_ENTITY_DEAD(clown, 0)) then
				if (not IS_PED_IN_ANY_VEHICLE(clown, true)) then
					SET_PED_FLEE_ATTRIBUTES(clown, 2, true);
					TASK_REACT_AND_FLEE_PED(clown, player);

					clowns[it] = nil; -- has left the vehicle, no reason to keep tracking it
				end
			else
				clowns[it] = nil;
			end
		end
	end
end

function OnStop()
	clowns = {};
end
