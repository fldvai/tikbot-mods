--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Cryptocurrency",
    ScriptId = "player_randommoney",
    TimedType = "Normal"
};

function OnStart()
    lastTick = GetTickCount();
end

function OnTick()
    local curTick = GetTickCount();
    if curTick - lastTick > 500 then
        lastTick = curTick;

        for i = 0,2 do
            local money = Holder();

            STAT_GET_INT(GET_HASH_KEY("SP" .. i .. "_TOTAL_CASH"), money, -1);
            STAT_SET_INT(GET_HASH_KEY("SP" .. i .. "_TOTAL_CASH"), 
                math.random(money:AsInteger() // 5, money:AsInteger() * 2 + 1), 1
            );
        end
    end
end
