
--[[
 * Effect by kolyaventuri
 --]]

ScriptInfo = {
	Name = "Signal distress",
	ScriptId = "peds_signal"
};

function CreateRandomPoolPed(fPosX, fPosY, fPosZ, fHeading)
	c_rgPedModels = GetAllPedModels();

	if #c_rgPedModels ~= 0 then
		model = c_rgPedModels[math.random(1, #c_rgPedModels)];

		ped = CreatePoolPed(4, model, fPosX, fPosY, fPosZ, fHeading);
	else
		ped = CREATE_RANDOM_PED(fPosX, fPosY, fPosZ);

		SET_ENTITY_HEADING(ped, fHeading);
    end

	for i = 0, 12 do
        drawableAmount = GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(ped, i);
        if drawableAmount == 0 then
            drawable = 0;
        else
            drawable = math.random(0, drawableAmount - 1);
        end

        textureAmount  = GET_NUMBER_OF_PED_TEXTURE_VARIATIONS(ped, i, drawable);
        if textureAmount == 0 then
            texture = 0;
        else
            texture = math.random(0, textureAmount - 1);
        end

		SET_PED_COMPONENT_VARIATION(ped, i, drawable, texture, math.random(0, 3));

		if i < 4 then
            propDrawableAmount = GET_NUMBER_OF_PED_PROP_DRAWABLE_VARIATIONS(ped, i);
            if propDrawableAmount == 0 then
                propDrawable = 0;
            else
                propDrawable = math.random(0, propDrawableAmount - 1);
            end

            propTextureAmount  = GET_NUMBER_OF_PED_PROP_TEXTURE_VARIATIONS(ped, i, drawable);
            if propTextureAmount == 0 then
                propTexture = 0;
            else
                propTexture = math.random(0, propTextureAmount - 1);
            end

            SET_PED_PROP_INDEX(ped, i, propDrawable, propTexture, true);
        end
	end

	return ped;
end

NUM = 6; -- Historically this should be 60 but that seems a bit much
variance = 0.005;

function OnStart()
    playerGroup = GET_HASH_KEY("PLAYER");
    civGroup = GET_HASH_KEY("CIVMALE");

    relationshipGroupHolder = Holder();
    ADD_RELATIONSHIP_GROUP("_HOSTILE_RANDOM", relationshipGroupHolder);
	relationshipGroup = relationshipGroupHolder:AsInteger();
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, relationshipGroup, playerGroup);
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, relationshipGroup, civGroup);

    player = PLAYER_PED_ID();
    pos = GET_ENTITY_COORDS(player, false);

    for i = 0, NUM do
        newPos = pos;
        newPos.x = newPos.x * (math.random() * 2 * variance + 1 - variance);
        newPos.y = newPos.y * (math.random() * 2 * variance + 1 - variance);;

        ped = CreateRandomPoolPed(newPos.x, newPos.y, newPos.z, GET_ENTITY_HEADING(player));
        if (IS_PED_IN_ANY_VEHICLE(player, false)) then
            SET_PED_INTO_VEHICLE(ped, GET_VEHICLE_PED_IS_IN(player, false), -2);
        end

        SET_PED_RELATIONSHIP_GROUP_HASH(ped, relationshipGroup);
        SET_PED_HEARING_RANGE(ped, 9999);
        SET_PED_CONFIG_FLAG(ped, 281, true);

        SET_PED_COMBAT_ATTRIBUTES(ped, 5, true);
        SET_PED_COMBAT_ATTRIBUTES(ped, 46, true);

        GIVE_WEAPON_TO_PED(ped, GET_HASH_KEY("WEAPON_FLAREGUN"), 1, false, true);
        SET_PED_ACCURACY(ped, 30);
    end
end