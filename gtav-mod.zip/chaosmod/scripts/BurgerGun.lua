ScriptInfo = {
    Name = "Big Mac Guns",
    ScriptId = "guns_burger",
    TimedType = "Normal"
}

function GetPlayerMoneyStat()
    local player = GET_ENTITY_MODEL(PLAYER_PED_ID());
    if player == GET_HASH_KEY("player_zero") then
        return "SP0_TOTAL_CASH";
    elseif player == GET_HASH_KEY("player_one") then
        return "SP1_TOTAL_CASH";
    elseif player == GET_HASH_KEY("player_two") then
        return "SP2_TOTAL_CASH";
    end
end

function DegToRadian(angles)
    return Vector3(angles.x * 0.0174532925199433, angles.y * 0.0174532925199433, angles.z * 0.0174532925199433);
end

function GetCoordsFromGameplayCam(fDistance)
    local vRot    = DegToRadian(GET_GAMEPLAY_CAM_ROT(2));
    local vCoords = GET_GAMEPLAY_CAM_COORD();

    vRot.y          = fDistance * math.cos(vRot.x);
    vCoords.x       = vCoords.x + vRot.y * math.sin(vRot.z * -1.0);
    vCoords.y       = vCoords.y + vRot.y * math.cos(vRot.z * -1.0);
    vCoords.z       = vCoords.z + fDistance * math.sin(vRot.x);

    return vCoords;
end

function IsWeaponShotgun(wep)
    if wep == (487013001 or 2017895192 or -1654528753 or -494615257 or -1466123874 or 984333226 or -275439685 or 317205821) then
        return true;
    end
    return false;
end

function OnTick()
	local burgerHash = GET_HASH_KEY("prop_cs_burger_01");
	LoadModel(burgerHash);

    SHOW_HUD_COMPONENT_THIS_FRAME(3);

	for _, ped in ipairs(GetAllPeds()) do
		if IS_PED_SHOOTING(ped) then
			local spawnBasePos;
			local spawnRot;

			if IS_PED_A_PLAYER(ped) then
				local camCoords  = GET_GAMEPLAY_CAM_COORD();
				local pedPos     = GET_ENTITY_COORDS(ped, false);

				local distCamToPed = GET_DISTANCE_BETWEEN_COORDS(pedPos.x, pedPos.y, pedPos.z, camCoords.x, camCoords.y,
				                                                 camCoords.z, true);

				spawnBasePos       = GetCoordsFromGameplayCam(distCamToPed + 0.5);
				spawnRot           = GET_GAMEPLAY_CAM_ROT(2);
			else
				spawnBasePos = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped, 0.0, 1.0, 0.0);
				spawnRot     = GET_ENTITY_ROTATION(ped, 2);
            end

			local isShotgun = IsWeaponShotgun(GET_SELECTED_PED_WEAPON(ped));
			local catCount   = (function() if isShotgun then return 3 else return 1 end end)()
			for i = 0, catCount, 1 do
				if i > 0 then
					WAIT(0);
                end

				local spawnPos = spawnBasePos;
				if isShotgun then
					spawnPos.z = spawnBasePos.z - 0.25 + i * 0.25;
                end

				local burger = CreatePoolProp(burgerHash, spawnPos.x, spawnPos.y, spawnPos.z, true);
				SET_ENTITY_ROTATION(burger, spawnRot.x, spawnRot.y, spawnRot.z, 2, true);

                SET_ENTITY_COLLISION(burger, true, true);
                SET_ENTITY_HAS_GRAVITY(burger, true);
                
                SET_ENTITY_LOD_DIST(burger, GET_ENTITY_LOD_DIST(PLAYER_PED_ID()))

				APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(burger, 1, 0.0, 250.0, 0.0, 0, 1, 1, 0);

				SET_OBJECT_AS_NO_LONGER_NEEDED(Holder(burger));
			end

            local money = Holder();
            STAT_GET_INT(GET_HASH_KEY(GetPlayerMoneyStat()), money, -1);
            print(tostring(money:AsInteger()));
            STAT_SET_INT(GET_HASH_KEY(GetPlayerMoneyStat()), money:AsInteger()-702, true);
		end
	end

	SET_MODEL_AS_NO_LONGER_NEEDED(burgerHash);
end