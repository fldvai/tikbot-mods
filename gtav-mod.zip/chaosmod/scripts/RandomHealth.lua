ScriptInfo = {
    Name = "Random Health",
    ScriptId = "player_randomhealth"
}

function OnStart()
    local ped = PLAYER_PED_ID();
    local maxHealth = GET_ENTITY_MAX_HEALTH(ped);
    SET_ENTITY_HEALTH(ped, math.random(maxHealth-99, maxHealth), 0);
end