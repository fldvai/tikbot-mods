ScriptInfo = {
	Name = "Peds Wave Hello",
	ScriptId = "peds_wave_hello",
	TimedType = "Normal"
};

--Effect by ProfessorBiddle

lastTick = 0;

function OnStop()
	REMOVE_ANIM_DICT("friends@frj@ig_1");
end

function OnTick()
	REQUEST_ANIM_DICT("friends@frj@ig_1");
	playerPed = PLAYER_PED_ID();

	curTick = GET_GAME_TIMER();

	if (lastTick < curTick - 5000) then
		lastTick = curTick;
		

		for _, ped in ipairs(GetAllPeds()) do
			if (not IS_ENTITY_PLAYING_ANIM(ped, "friends@frj@ig_1", "wave_a", 3) and not IS_PED_A_PLAYER(ped) and IS_PED_HUMAN(ped) and not IS_ENTITY_A_MISSION_ENTITY(ped)) then
				TASK_TURN_PED_TO_FACE_ENTITY(ped, playerPed, 1);
				
				TASK_PLAY_ANIM(ped, "friends@frj@ig_1", "wave_a", 4.0, -4.0, -1, 1, 0.0, false, false, false);
				
				PLAY_PED_AMBIENT_SPEECH_NATIVE(ped, "GENERIC_HI", "SPEECH_PARAMS_FORCE_SHOUTED", 1);
			end
		end
	end


end