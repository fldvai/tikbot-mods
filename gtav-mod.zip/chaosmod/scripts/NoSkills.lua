--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "No Skills",
    ScriptId = "player_noskills",
    TimedType = "None"
};

function OnStart()
    local abilities = {
        "SPECIAL_ABILITY_UNLOCKED",
        "STAMINA",
        "SHOOTING_ABILITY",
        "STRENGTH",
        "STEALTH_ABILITY",
        "FLYING_ABILITY",
        "WHEELIE_ABILITY",
        "LUNG_CAPACITY"
    }

    -- we don't need it anyway, right?
    TERMINATE_ALL_SCRIPTS_WITH_THIS_NAME("stats_controller")

    for i = 0,2 do
        for _, ability in ipairs(abilities) do
            STAT_SET_INT(GET_HASH_KEY("SP" .. i .. "_" .. ability), 0, 1);
        end
    end
end

