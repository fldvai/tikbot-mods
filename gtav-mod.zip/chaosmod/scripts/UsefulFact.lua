--[[
    Effect by OnlyRealNubs
--]]

ScriptInfo = {
	Name = "Useful Fact",
	ScriptId = "player_facts"
};

messages = {
       "Press ~INPUT_MOVE_UP_ONLY~ to walk",
       "Click the shoot button to shoot your gun",
       "Use buttons to play the game",
       "If you look at the screen, you can see the game",
       "If you get shot you will take damage",
       "If you take damage, your health will decrease",
       "If you die, you will be dead",
       "When you kill someone, they have a 50% chance of actually dying.",
       "This is text",
       "There aren’t cougars in missions",
       "GTA Online is full of modders. AVOID AT ALL COSTS",
       "This is truly… millions to one",
       "You’re very good at this game. You should try speedrunning it",
       "hi",
       "Here is a random video: ~n~ https://youtu.be/dQw4w9WgXcQ",
       "Griefer Jesus is a good guy.",
       "You have to know something about something, otherwise you couldn’t tie your shoes",
       "To fly in a car it needs to have wings",
       "If you get a wanted level you will be wanted",
       "I’m running out of ideas on what to put here",
};

function OnStart()
    if (IS_HELP_MESSAGE_BEING_DISPLAYED()) then
        CLEAR_HELP(1);
    end
    messageToDisplay = messages[math.random(1, #messages)];
    BEGIN_TEXT_COMMAND_DISPLAY_HELP("STRING");
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(messageToDisplay);
    END_TEXT_COMMAND_DISPLAY_HELP(0, 0, 1, -1);
end