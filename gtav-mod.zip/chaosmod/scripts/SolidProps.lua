--[[
    Effect by Reguas
--]]

ScriptInfo = {
	Name = "Solid Props",
	ScriptId = "misc_solid_props",
    TimedType = "Normal"
};

function OnTick()
    for _, prop in ipairs(GetAllProps()) do
        SET_DISABLE_BREAKING(prop, true);
    end
end

function OnStop()
    for _, prop in ipairs(GetAllProps()) do
        SET_DISABLE_BREAKING(prop, false);
    end
end