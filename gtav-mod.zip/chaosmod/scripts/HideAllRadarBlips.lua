--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Where To Next?",
    ScriptId = "misc_hideblips",
    TimedType = "Normal"
};

local blips = {};

local blips_with_routes = {};

local waypointCoords = nil;

function OnStart()
    blips = {};
    blips_with_routes = {};
    waypointCoords = nil;
end

function OnTick()
    if (IS_WAYPOINT_ACTIVE()) then
        waypointCoords = GET_BLIP_COORDS(GET_FIRST_BLIP_INFO_ID(8));
    end
    SET_WAYPOINT_OFF();

    for i = 0,834 do
        local blip = GET_FIRST_BLIP_INFO_ID(i);
        while DOES_BLIP_EXIST(blip) do
            if blips[blip] == nil then
                blips[blip] = GET_BLIP_ALPHA(blip);
            end

            if DOES_BLIP_HAVE_GPS_ROUTE(blip) then
                table.insert(blips_with_routes, blip);
                SET_BLIP_ROUTE(blip, false);
            end

            SET_BLIP_ALPHA(blip, 0);
            blip = GET_NEXT_BLIP_INFO_ID(i);
        end
    end
end


function OnStop()
    SET_MINIMAP_BLOCK_WAYPOINT(false);

    if waypointCoords ~= nil then
        SET_NEW_WAYPOINT(waypointCoords.x, waypointCoords.y);
    end

    for blip, alpha in pairs(blips) do
        if DOES_BLIP_EXIST(blip) then
            SET_BLIP_ALPHA(blip, alpha);
        end
    end

    for _, blip in ipairs(blips_with_routes) do
        if DOES_BLIP_EXIST(blip) then
            SET_BLIP_ROUTE(blip, true);
        end
    end
end