--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Roadkill",
    ScriptId = "misc_spawndeer",
    TimedType = "None"
};

function OnStart()
    local deerModel = GET_HASH_KEY("A_C_Deer");
    local truckModel = GET_HASH_KEY("mule4");

    LoadModel(deerModel);

    local player = PLAYER_PED_ID();
    local pos = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player, 0.0, 6.0, 0.0);
    local angle = GET_ENTITY_HEADING(player);

    local playerVeh;
    if not IS_PED_IN_ANY_VEHICLE(player, false) then
        playerVeh = CreateTempVehicleOnPlayerPos(truckModel, angle);
		SET_PED_INTO_VEHICLE(player, playerVeh, -1);
    else
        playerVeh = GET_VEHICLE_PED_IS_IN(player, false);
    end

    SET_VEHICLE_FORWARD_SPEED(playerVeh, 30.0);

    CreatePoolPed(28, deerModel, pos.x, pos.y, pos.z, angle + 90);
end

