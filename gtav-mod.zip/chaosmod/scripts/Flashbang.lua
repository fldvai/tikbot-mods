--[[
    Effect by OnlyRealNubs
--]]

ScriptInfo = {
	Name = "Flashbang",
	ScriptId = "misc_flashbang",
};

function OnStart()
    ticksToDraw = GetTickCount() + 2000;

    while GetTickCount() < ticksToDraw do
        WAIT(0);
        DRAW_RECT(0.0, 0.0, 2.0, 2.0, 255, 255, 255, 255, 0);
    end

    alphaMult = 1.0;
    lastTick = GetTickCount();
    while alphaMult > 0.0 do
        
        curTick = GetTickCount()
        if curTick - lastTick > 50 then
            alphaMult = alphaMult - 0.01;
            lastTick = curTick;
        end

        DRAW_RECT(0.0, 0.0, 2.0, 2.0, 255, 255, 255, math.floor(255*alphaMult), 0);

        WAIT(0);
    end
end