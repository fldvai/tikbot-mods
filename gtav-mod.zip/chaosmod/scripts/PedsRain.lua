--[[
	Effect by Gorakh
--]]

ScriptInfo = {
	Name = "It's Raining Men",
	ScriptId = "misc_ped_rain",
	TimedType = "Normal"
};

SPAWN_HEIGHT = 50.0;

-- s = (a * t^2)/2
-- t = sqrt((s*2)/a)
-- Estimated fall time, in seconds
estimatedFallTime = math.sqrt((SPAWN_HEIGHT * 2.0) / 9.8);

-- Estimated fall time, in milliseconds
estimatedFallTime_ms = estimatedFallTime * 1000.0;

fallingPeds = {};

lastTick = 0;

function length(vec)
	return vec.x * vec.x + vec.y * vec.y + vec.z * vec.z;
end

function OnTick()
	curTick = GET_GAME_TIMER();

	if (curTick > lastTick + 300) then
		lastTick = curTick;

		pedModels = GetAllPedModels();
		if #fallingPeds == 0 then
			player = PLAYER_PED_ID();

			playerPos = GET_ENTITY_COORDS(player, false);
			playerVelocity = GET_ENTITY_VELOCITY(player);

			if (length(playerVelocity) > 0.0) then
				-- If player is moving, predict the future position and spawn peds there instead
				playerPos.x = playerPos.x + (playerVelocity.x * estimatedFallTime);
				playerPos.y = playerPos.y + (playerVelocity.y * estimatedFallTime);
				playerPos.z = playerPos.z + (playerVelocity.z * estimatedFallTime);
			end

			spawnPos = Vector3(0, 0, 0);
			spawnPos.x = playerPos.x + math.random(-50, 50);
			spawnPos.y = playerPos.y + math.random(-50, 50);
			spawnPos.z = playerPos.z + SPAWN_HEIGHT;

			model = pedModels[math.random(1, #pedModels)];
			ped = CreatePoolPed(4, model, spawnPos.x, spawnPos.y, spawnPos.z, 0.0);

			SET_ENTITY_HEALTH(ped, 101, 0); -- For some reason this is needed for the peds to ragdoll properly?????

			SET_PED_CAN_RAGDOLL(ped, true);

			fallingPeds[ped] = GET_GAME_TIMER();
		end
	end

	count = 5;
	for ped, time in ipairs(fallingPeds) do
		if (not DOES_ENTITY_EXIST(ped) or GET_ENTITY_HEIGHT_ABOVE_GROUND(ped) <= 2.0 or GET_GAME_TIMER() > time + estimatedFallTime_ms) then
			if (DOES_ENTITY_EXIST(ped)) then
				SET_ENTITY_HEALTH(ped, 0, 0);
			end
			count = count - 1;
			if (count == 0) then
				WAIT(0);
				count = 5;
			end
		end
	end
end