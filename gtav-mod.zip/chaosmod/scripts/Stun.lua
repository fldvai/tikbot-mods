--[[
    Effect by OnlyRealNubs
--]]

ScriptInfo = {
	Name = "That's Stunning",
	ScriptId = "player_stun"
};

effectName = "Dont_tazeme_bro";

function OnStart()
    plr = PLAYER_PED_ID();

    CLEAR_PED_LAST_WEAPON_DAMAGE(plr);
    SET_PED_MIN_GROUND_TIME_FOR_STUNGUN(plr, 4500);

    REQUEST_WEAPON_ASSET(911657153, 31, 0);
    while not HAS_WEAPON_ASSET_LOADED(911657153) do
        WAIT(0);
    end

    for i = 1, 8, 1 do
        boneId = GET_PED_BONE_INDEX(plr, 24818);

        to = GET_PED_BONE_COORDS(plr, boneId, 0.0, 0.0, 0.5);
        from = GET_PED_BONE_COORDS(plr, boneId, 0.0, -1.0, 0.5);

        SHOOT_SINGLE_BULLET_BETWEEN_COORDS(from.x, from.y, from.z, to.x, to.y, to.z, 10, true, 911657153, 0, true, false, 2000000.0);

        WAIT(200);

        if IS_PED_BEING_STUNNED(plr, 0) then
            ANIMPOSTFX_PLAY(effectName, 0, 0);
            WAIT(4500);
            NIMPOSTFX_STOP(effectName);
            break;
        end
    end
end