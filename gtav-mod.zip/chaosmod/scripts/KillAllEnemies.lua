--[[
    Effect by Reguas
--]]

ScriptInfo = {
	Name = "Kill All Enemies",
	ScriptId = "peds_kill_all_enemies",
    TimedType = "None"
};

function GetAllEnemies()
    enemies = {}

    player = PLAYER_PED_ID()

    for _, ped in ipairs(GetAllPeds()) do
        if GET_RELATIONSHIP_BETWEEN_PEDS(player, ped) >= 4 or GET_RELATIONSHIP_BETWEEN_PEDS(ped, player) >= 4 then
            table.insert(enemies, ped)
        end
    end

    return enemies
end

function OnStart()
    for _, enemy in ipairs(GetAllEnemies()) do
        SET_ENTITY_HEALTH(enemy, 0, 0)
    end
end