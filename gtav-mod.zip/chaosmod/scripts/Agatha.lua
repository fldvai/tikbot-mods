ScriptInfo = {
    Name = "Hello, this is Agatha",
    ScriptId = "shutthef_ckupagatha",
}

function GetPlayerCharacter()
    local m = GET_ENTITY_MODEL(PLAYER_PED_ID());
    if m == GET_HASH_KEY("player_zero") then
        return "MICHAEL";
    elseif m == GET_HASH_KEY("player_one") then
        return "FRANKLIN";
    elseif m == GET_HASH_KEY("player_two") then
        return "TREVOR";
    end
    return "";
end

function OnStart()
    local plr = PLAYER_PED_ID();

    if IS_SCRIPTED_CONVERSATION_ONGOING() or IS_MOBILE_PHONE_CALL_ONGOING() then
        STOP_SCRIPTED_CONVERSATION(false);
    end

    if IS_PED_RUNNING_MOBILE_PHONE_TASK(plr) then
        while IS_PED_RUNNING_MOBILE_PHONE_TASK(plr) do
            SET_CONTROL_VALUE_NEXT_FRAME(0, 177, 1.0);
            WAIT(0);
        end
    end

    EnableScriptThreadBlock();

    CLEAR_ADDITIONAL_TEXT(14, false)
    REQUEST_ADDITIONAL_TEXT_FOR_DLC("CAGTAU", 14);
    while not HAS_ADDITIONAL_TEXT_LOADED(14) do
        WAIT(0);
    end

    local baker = 0;
    
    if IS_PED_IN_ANY_VEHICLE(plr, true) then
        local veh = GET_VEHICLE_PED_IS_USING(plr);
        local seat = -2;
        for i = -1, GET_VEHICLE_MODEL_NUMBER_OF_SEATS(GET_ENTITY_MODEL(veh)), 1 do
            if IS_VEHICLE_SEAT_FREE(veh, i, true) then
                seat = i;
            end
        end
        if seat >= -1 then
            local plrCoords = GET_ENTITY_COORDS(plr, true);
            baker = CreatePoolPed(0, 1855569864, plrCoords.x, plrCoords.y, plrCoords.z, 0.0);
            SET_PED_INTO_VEHICLE(baker, veh, seat)
        else
            local plrCoords = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(plr, 1.5, 0.0, 0.0);
            baker = CreatePoolPed(0, 1855569864, plrCoords.x, plrCoords.y, plrCoords.z, 0.0);
        end
    else
        local plrCoords = GET_ENTITY_COORDS(plr, true);
        baker = CreatePoolPed(0, 1855569864, plrCoords.x, plrCoords.y, plrCoords.z, 0.0);
    end

    local rl = Holder();
    local plrRl = GET_HASH_KEY("PLAYER");
    ADD_RELATIONSHIP_GROUP("_COMPANION_BRAD", rl);
	SET_RELATIONSHIP_BETWEEN_GROUPS(0, rl:AsInteger(), plrRl);
	SET_RELATIONSHIP_BETWEEN_GROUPS(0, plrRl, rl:AsInteger());
    SET_PED_AS_GROUP_MEMBER(baker, GET_PLAYER_GROUP(PLAYER_ID()));

    CREATE_NEW_SCRIPTED_CONVERSATION();

    ADD_PED_TO_CONVERSATION(0, baker, "CAS_AGATHA");
    ADD_PED_TO_CONVERSATION(1, plr, GetPlayerCharacter())

    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAA", "CAGT_M1_UC1_1", 1, 0, false, false, true, true, 0, false, false, false);
    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAB", "CAGT_M1_UC1_3", 1, 0, false, false, true, true, 0, false, false, false);
    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAC", "CAGT_M1_UC1_5", 1, 0, false, false, true, true, 0, false, false, false);
    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAD", "CAGT_M1_UC1_7", 1, 0, false, false, true, true, 0, false, false, false);
    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAE", "CAGT_M1_UC1_9", 1, 0, false, false, true, true, 0, false, false, false);
    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAF", "CAGT_M1_UC1_10", 1, 0, false, false, true, true, 0, false, false, false);
    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAG", "CAGT_M1_UC1_11", 1, 0, false, false, true, true, 0, false, false, false);
    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAH", "CAGT_M1_UC1_12", 1, 0, false, false, true, true, 0, false, false, false);
    ADD_LINE_TO_CONVERSATION(0, "CAGT_HAAI", "CAGT_M1_UC1_14", 1, 0, false, false, true, true, 0, false, false, false);

    SET_PED_CAN_USE_AUTO_CONVERSATION_LOOKAT(plr, true);
    SET_PED_CAN_USE_AUTO_CONVERSATION_LOOKAT(baker, true);

    START_SCRIPT_CONVERSATION(true, true, true, true);

    while IS_SCRIPTED_CONVERSATION_ONGOING() do
        WAIT(0);
    end

    CLEAR_RELATIONSHIP_BETWEEN_GROUPS(0, rl:AsInteger(), plrRl);
    CLEAR_RELATIONSHIP_BETWEEN_GROUPS(0, plrRl, rl:AsInteger());

    if IS_PED_IN_ANY_VEHICLE(baker, false) then
        TASK_LEAVE_ANY_VEHICLE(baker, 0, 4160);
    end

    SET_ENTITY_AS_NO_LONGER_NEEDED(Holder(baker))

    DisableScriptThreadBlock();
end