ScriptInfo = {
    Name = "Raspberry Rain",
    ScriptId = "raspberry_rain",
    TimedType = "Normal"
}

local MAX_BALLS = 20;
local BALL_MODEL = 1022578470;

local balls = {};
local ballDespawnTime = {};
local ballAmount = 0;

function OnStart()
    balls = {};
    ballDespawnTime = {};
    ballAmount = 0;
end

function OnStop()
    for _, ball in ipairs(balls) do
        SET_OBJECT_AS_NO_LONGER_NEEDED(Holder(ball));
    end
end

function OnTick()

	local playerPos = GET_ENTITY_COORDS(PLAYER_PED_ID(), false);

	local lastTick = 0;
	local curTick = GET_GAME_TIMER();

	if ballAmount <= MAX_BALLS and curTick > lastTick + 200 then
		lastTick = curTick;

		local spawnPos = Vector3(playerPos.x + math.random(-100, 100), playerPos.y + math.random(-100, 100), playerPos.z + math.random(25, 50));

		LoadModel(BALL_MODEL);

		local ball = CreatePoolProp(BALL_MODEL, spawnPos.x, spawnPos.y, spawnPos.z, false);

		ballAmount = ballAmount + 1;
		for i = 0, MAX_BALLS, 1 do
			local obj = balls[i];
			if not DOES_ENTITY_EXIST(obj) then
				obj                 = ball;
				ballDespawnTime[i] = 5;
				break;
            end
		end

		APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(ball, 0, 35.0, 0.0, -5000.0, 1, 0, 1, 1);

		SET_MODEL_AS_NO_LONGER_NEEDED(BALL_MODEL);
	end

	local lastTick2 = 0;
	for i = 0, MAX_BALLS, 1 do
		local ball = balls[i];
		if ball ~= (0 or nil) then
			if DOES_ENTITY_EXIST(ball) and ballDespawnTime[i] > 0 then
				local propPos = GET_ENTITY_COORDS(ball, false);
				if GET_DISTANCE_BETWEEN_COORDS(playerPos.x, playerPos.y, playerPos.z, propPos.x, propPos.y, propPos.z,true) < 400.0 then
					if HAS_ENTITY_COLLIDED_WITH_ANYTHING(ball) then
						if (lastTick2 < curTick - 1000) then
                            ballDespawnTime[i] = ballDespawnTime[i] - 1;
                        end
					end
					goto continue;
				end
			end

			ballAmount = ballAmount - 1;
			SET_OBJECT_AS_NO_LONGER_NEEDED(Holder(ball));

			ball = 0;
		end
	    ::continue::
	end

	if lastTick2 < curTick - 1000 then
		lastTick2 = curTick;
    end
end