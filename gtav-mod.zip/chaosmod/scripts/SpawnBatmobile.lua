-- Script by iCeParadox64

ScriptInfo = {
	Name = "Spawn Vigilante",
	ScriptId = "veh_batmobile"
};

function OnStart()
    modelHash = -1242608589;

    playerPed = PLAYER_PED_ID();
    playerPos = GET_ENTITY_COORDS(playerPed, false);

    veh = CreatePoolVehicle(modelHash, playerPos.x, playerPos.y, playerPos.z, 0.0);
end