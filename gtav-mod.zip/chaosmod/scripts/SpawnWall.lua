ScriptInfo = {
    Name = "Spawn Invisible Wall",
    ScriptId = "spawn_wall"
}

function OnStart()
    local model = GET_HASH_KEY("prop_huge_display_01")
    local spawnPos = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER_PED_ID(), 0, 4.0, 0);
    LoadModel(model);
    SET_ENTITY_ALPHA(CreatePoolProp(model, spawnPos.x, spawnPos.y, spawnPos.z, true), 0, false);
end