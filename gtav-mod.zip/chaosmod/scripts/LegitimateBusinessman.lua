--[[
    Effect by Reguas
--]]

ScriptInfo = {
	Name = "Legitimate Businessman",
	ScriptId = "peds_angrysimeon",
    EffectGroup = "_group_spawnenemy"
};

function LoadModel(ulModel)
	if IS_MODEL_VALID(ulModel) then
		REQUEST_MODEL(ulModel);
		while not HAS_MODEL_LOADED(ulModel) do
			WAIT(0);
		end
	end
end

function OnStart()
    modelHashSimeon = 0xC0937202;
    modelHashLamar = 0x65B93076;
    modelHashFranklin = 0x9B22DBAF;
	
	LoadModel(modelHashFranklin);
	LoadModel(modelHashLamar);
	LoadModel(modelHashSimeon);
	
    playerPed = PLAYER_PED_ID();
    playerPos = GET_ENTITY_COORDS(playerPed, false);

    playerGroup = GET_HASH_KEY("PLAYER");

    relationshipGroupHolder = Holder();
    ADD_RELATIONSHIP_GROUP("_HOSTILE_SIMEON", relationshipGroupHolder);
	relationshipGroup = relationshipGroupHolder:AsInteger();
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, relationshipGroup, playerGroup);
    SET_RELATIONSHIP_BETWEEN_GROUPS(5, playerGroup, relationshipGroup);

    ped = CreatePoolPed(4, modelHashSimeon, playerPos.x - 2, playerPos.y, playerPos.z, 0.0);

    SET_PED_RELATIONSHIP_GROUP_HASH(ped, relationshipGroup);
    SET_PED_HEARING_RANGE(ped, 9999.0);
    SET_PED_CONFIG_FLAG(ped, 281, true);

    SET_PED_COMBAT_ATTRIBUTES(ped, 5, true);
    SET_PED_COMBAT_ATTRIBUTES(ped, 46, true);

    SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(ped, false);
    SET_RAGDOLL_BLOCKING_FLAGS(ped, 7);

    TASK_COMBAT_PED(ped, playerPed, 0, 16);

    if (IS_PED_IN_ANY_VEHICLE(playerPed, false)) then
        veh = GET_VEHICLE_PED_IS_IN(playerPed, false);
        BRING_VEHICLE_TO_HALT(veh, 0.1, 10, 0);
        pedAssistant = CreatePoolPed(4, math.random(0, 1) == 0 and modelHashLamar or modelHashFranklin, playerPos.x - 2, playerPos.y, playerPos.z, 0.0);

        SET_PED_RELATIONSHIP_GROUP_HASH(pedAssistant, relationshipGroup);
        SET_RAGDOLL_BLOCKING_FLAGS(pedAssistant, 2);

        TASK_VEHICLE_DRIVE_WANDER(pedAssistant, veh, 9999.0, 572);

        SET_PED_KEEP_TASK(pedAssistant, true);

        SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(pedAssistant, true);

        TASK_PAUSE(ped, 1500);
		WAIT(1500);
		TASK_COMBAT_PED(ped, playerPed, 0, 16);
    end

    REMOVE_ALL_PED_WEAPONS(playerPed, false);
end