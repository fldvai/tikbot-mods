ScriptInfo = {
	Name = "Cola Rain",
	ScriptId = "player_colarain",
	TimedType = "Normal"
};

function OnStop()
	SET_MODEL_AS_NO_LONGER_NEEDED(GET_HASH_KEY("prop_ecola_can"));

	SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(PLAYER_ID(), 1);
	SET_ENTITY_HEALTH(PLAYER_ID(), GET_PED_MAX_HEALTH(PLAYER_ID()), 0);
end

function OnStart()
	SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(PLAYER_ID(), 0);
	SET_ENTITY_HEALTH(GET_PLAYER_PED(PLAYER_ID()), 101, 0);
	SET_PED_ARMOUR(GET_PLAYER_PED(PLAYER_ID()), 0);

end

function OnTick()
	model = GET_HASH_KEY("prop_ecola_can");
	REQUEST_MODEL(model);

	playerPos = GET_ENTITY_COORDS(PLAYER_PED_ID(), false);
	CREATE_AMBIENT_PICKUP(GET_HASH_KEY("PICKUP_HEALTH_STANDARD"), playerPos.x + math.random(-30, 30),
		playerPos.y + math.random(-30, 30), playerPos.z + math.random(5, 10), 0, GET_ENTITY_MAX_HEALTH(GET_PLAYER_PED(PLAYER_ID())), model, false, true);
end