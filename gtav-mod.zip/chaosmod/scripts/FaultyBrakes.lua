ScriptInfo = {
	Name = "Faulty Brakes",
	ScriptId = "vehs_faulty_brakes",
	TimedType = "Short"
};

local lastTick = 0;

function OnTick()
    local curTick = GetTickCount();
    local playerPed = PLAYER_PED_ID();

    local veh = GET_VEHICLE_PED_IS_IN(playerPed, 0);
    if (not DOES_ENTITY_EXIST(veh)) then
        return;
	end

    if (lastTick < curTick - 500) then
        lastTick = curTick;

        local rng = math.random(0, 100);
        if (rng <= 40) then
            local brakeTime = math.random(200, 1000);
            while GetTickCount() - curTick > brakeTime do
                if IsVehicleBraking(veh) then
                    DISABLE_CONTROL_ACTION(0, 72, true);
                    DISABLE_CONTROL_ACTION(0, 76, true);
                    SET_VEHICLE_BRAKE(veh, false);
                    SET_VEHICLE_HANDBRAKE(veh, false);
                else
                    SET_VEHICLE_BRAKE(veh, true);
                    SET_VEHICLE_HANDBRAKE(veh, true);
                end
                SET_VEHICLE_BRAKE_LIGHTS(veh, false);
            end
        end
    end
end