ScriptInfo = {
    Name = "Blue World",
    ScriptId = "screen_blueworld",
    TimedType = "Normal",
    EffectCategory = "Shader",
}

function OnStart()
    OverrideShader(EOverrideShaderType.Snow, [[
float4 main(float4 v0 : SV_Position0, float4 v1 : TEXCOORD0, float4 v2 : TEXCOORD1) : SV_Target0
{
    return float4(0, 0, 1, 1.);
}
]])
    SetSnowState(true);
end

function OnStop()
    SetSnowState(false);
    ResetShader();
end