--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Clown School",
    ScriptId = "peds_clownschool",
    TimedType = "None"
};

function OnStart()
    SetSurroundingPedsInVehicles(GET_HASH_KEY("speedo2"), 120)
end
