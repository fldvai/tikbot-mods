--[[
    Effect by Reguas
--]]

ScriptInfo = {
    Name = "Sticky Car",
    ScriptId = "vehicle_sticky",
    TimedType = "Normal"
}

attached = {}

function OnTick()
    local player = PLAYER_PED_ID()
    if (not IS_PED_IN_ANY_VEHICLE(player, false)) then
        do return end
    end

    local vehicle = GET_VEHICLE_PED_IS_IN(player, false)
    local entities = {}

    for _, ped in ipairs(GetAllPeds()) do
        if (ped ~= player) then
            table.insert(entities, ped)
        end
    end

    for _, veh in ipairs(GetAllVehicles()) do
        if veh ~= vehicle then
            table.insert(entities, veh)
        end
    end

    for _, prop in ipairs(GetAllProps()) do
        table.insert(entities, prop)
    end

    for _, entity in ipairs(entities) do
        if attached[entity] ~= true and IS_ENTITY_TOUCHING_ENTITY(vehicle, entity) then
            local coords = GET_ENTITY_COORDS(entity, false)
            local offset = GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS(vehicle, coords.x, coords.y, coords.z)
            local rot = GET_ENTITY_ROTATION(entity, 5)
            local vehRot = GET_ENTITY_ROTATION(vehicle, 5)
            ATTACH_ENTITY_TO_ENTITY(
                entity, vehicle, 0,
                offset.x, offset.y, offset.z,
                rot.x - vehRot.x, rot.y - vehRot.y, rot.z - vehRot.z,
                false, false, false, false, 0, true
            )

            attached[entity] = true
        end
    end
end

function OnStop()

    for entity, _ in pairs(attached) do
        if DOES_ENTITY_EXIST(entity) then
            DETACH_ENTITY(entity, true, false)
        end
    end
    attached = {}
end
