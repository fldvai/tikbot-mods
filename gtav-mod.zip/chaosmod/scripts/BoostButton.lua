--[[
    Effect By OnlyRealNubs
--]]

ScriptInfo = {
	Name = "What's the boost button? (E/LS)",
	ScriptId = "vehs_boost",
    TimedType = "Normal"
};

cooldownMax = 800; -- ms
force = 20.0;

canBoost = false;
cooldown = 0;

function OnTick()
    ped = PLAYER_PED_ID();
    veh = GET_VEHICLE_PED_IS_IN(ped, false);
    if (IS_CONTROL_JUST_PRESSED(0, 351) and canBoost) then
        canBoost = false;
        SET_VEHICLE_BOOST_ACTIVE(veh, true);
        SET_VEHICLE_FORWARD_SPEED(veh, GET_ENTITY_SPEED(veh) + force);
        ANIMPOSTFX_PLAY("RaceTurbo", 0, false);
        SET_VEHICLE_BOOST_ACTIVE(veh, false);
    end

    if (not canBoost and cooldown <= 1000) then
        if (cooldown >= 800) then
            cooldown = 0;
            canBoost = true;
        else
            cooldown = cooldown + 1;
        end
    end
end

function OnStart()
    canBoost = true;
    cooldown = 0;
end