--[[
    Effect by Reguas
--]]

ScriptInfo = {
	Name = "Frozen",
	ScriptId = "misc_frozen",
    TimedType = "Short"
};

freeEntities = {};

function OnStart()
    freeEntities[PLAYER_PED_ID()] = true;
end

function OnTick()
    player = PLAYER_PED_ID();
    touching = player;
    entities = {};

    for _, ped in ipairs(GetAllPeds()) do
        if (ped ~= player) then
            table.insert(entities, ped);
        end
    end

    for _, veh in ipairs(GetAllVehicles()) do
        if (not IS_PED_IN_VEHICLE(player, veh, false)) then
            table.insert(entities, veh);
        else
            freeEntities[veh] = true;
            touching = veh;
        end
    end

    for _, prop in ipairs(GetAllProps()) do
        table.insert(entities, prop);
    end

    for _, entity in ipairs(entities) do
        if (IS_ENTITY_TOUCHING_ENTITY(touching, entity)) then
            freeEntities[entity] = true;
        end

        if (freeEntities[entity]) then
            FREEZE_ENTITY_POSITION(entity, false);
        else
            if (IS_ENTITY_A_PED(entity)) then
                TASK_PAUSE(entity, 1);
            end
            if (IS_ENTITY_A_VEHICLE(entity)) then
                -- to avoid weird vehicle spawns
                SET_VEHICLE_ON_GROUND_PROPERLY(entity, 5.0);
            end
            FREEZE_ENTITY_POSITION(entity, true);
        end
    end
end

function OnStop()
    entities = {};

    for _, ped in ipairs(GetAllPeds()) do
        table.insert(entities, ped);
    end

    for _, veh in ipairs(GetAllVehicles()) do
        table.insert(entities, veh);
    end

    for _, prop in ipairs(GetAllProps()) do
        table.insert(entities, prop);
    end

    for _, entity in ipairs(entities) do
        FREEZE_ENTITY_POSITION(entity, false);
    end
end