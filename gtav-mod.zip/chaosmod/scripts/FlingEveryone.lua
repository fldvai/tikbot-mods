ScriptInfo = {
    Name = "Fling All Nearby Peds",
    ScriptId = "fling_everyone"
}

function OnStart()
    local count = 0;
    for _, ped in ipairs(GetAllPeds()) do
        if not IS_PED_IN_ANY_VEHICLE(ped, false) and not IS_PED_A_PLAYER(ped) then
            SET_PED_TO_RAGDOLL(ped, 5000, 5000, 0, true, true, false);
            APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(ped, 1, math.random(-100.0, 100.0), math.random(-100.0, 100.0), math.random(50.0, 100.0), 0, 0, 1, 0);
        end

        count = count + 1;
        if count == 5 then
            count = 0;
            WAIT(0);
        end
    end

    for _, veh in ipairs(GetAllVehicles()) do
        for i = -1, GET_VEHICLE_MODEL_NUMBER_OF_SEATS(GET_ENTITY_MODEL(veh)) - 2 do
            if not IS_VEHICLE_SEAT_FREE(veh, i, false) and not IS_PED_A_PLAYER(GET_PED_IN_VEHICLE_SEAT(veh, i, false)) then
                APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(veh, 1, math.random(-100.0, 100.0), math.random(-100.0, 100.0), math.random(50.0, 100.0), 0, 0, 1, 0);
                break;
            end
        end

        count = count + 1;
        if count == 5 then
            count = 0;
            WAIT(0);
        end
    end
end