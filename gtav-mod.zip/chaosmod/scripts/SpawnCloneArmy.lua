--[[
	Effect by Gorakh
--]]

ScriptInfo = {
	Name = "Spawn Clone Army",
	ScriptId = "player_clone_army"
};

NUM_CLONES = 8;

function OnStart()
	playerGroup = GET_HASH_KEY("PLAYER");

	maleCivGroup = GET_HASH_KEY("CIVMALE");
	femCivGroup = GET_HASH_KEY("CIVFEMALE");
	
	cloneGroupHolder = Holder()
	ADD_RELATIONSHIP_GROUP("_PLAYER_CLONES", cloneGroupHolder);
	cloneGroup = cloneGroupHolder:AsInteger();

	SET_RELATIONSHIP_BETWEEN_GROUPS(0, playerGroup, cloneGroup);
	SET_RELATIONSHIP_BETWEEN_GROUPS(0, cloneGroup, playerGroup);

	SET_RELATIONSHIP_BETWEEN_GROUPS(5, cloneGroup, maleCivGroup);
	SET_RELATIONSHIP_BETWEEN_GROUPS(5, cloneGroup, femCivGroup);

	playerPed = PLAYER_PED_ID();

	playerCoords = GET_ENTITY_COORDS(playerPed, true);
	playerPedType = GET_PED_TYPE(playerPed);
	playerModel = GET_ENTITY_MODEL(playerPed);
	playerHeading = GET_ENTITY_HEADING(playerPed);
	playerGroupID = GET_PLAYER_GROUP(PLAYER_ID());

	clones = {};

	count = 3;
	for i = 0, NUM_CLONES do
		clone = CreatePoolPed(playerPedType, playerModel, playerCoords.x + math.random() * 4 - 2, playerCoords.y + math.random() * 4 - 2, playerCoords.z, playerHeading);
		CLONE_PED_TO_TARGET(playerPed, clone);
		SET_PED_RELATIONSHIP_GROUP_HASH(clone, cloneGroup);

		SET_PED_SUFFERS_CRITICAL_HITS(clone, false);
		SET_PED_AS_GROUP_MEMBER(clone, playerGroupID);

		GIVE_WEAPON_TO_PED(clone, GET_SELECTED_PED_WEAPON(playerPed), 9999, false, true);

		SET_PED_FIRING_PATTERN(clone, 0xC6EE6B4C);

		SET_PED_PATH_CAN_DROP_FROM_HEIGHT(clone, true);
		SET_PED_PATH_CAN_USE_CLIMBOVERS(clone, true);
		SET_PED_PATH_CAN_USE_LADDERS(clone, true);
		SET_PED_PATH_MAY_ENTER_WATER(clone, true);

		SET_PED_MOVE_RATE_OVERRIDE(clone, 1.15);

		SET_PED_HEARING_RANGE(clone, 9999.0);
		SET_PED_SEEING_RANGE(clone, 9999.0);

		clones[clone] = true;

		count = count - 1;
		if (count == 0) then
			WAIT(0);
			count = 3;
		end
	end

	-- Make clones attack everyone who isn't another clone or the player
	for _, ped in ipairs(GetAllPeds()) do
		if (not IS_PED_A_PLAYER(ped) and not IS_PED_DEAD_OR_DYING(ped, true) and clones[ped]) then
			pedGroup = GET_PED_RELATIONSHIP_GROUP_HASH(ped);
			if (_DOES_RELATIONSHIP_GROUP_EXIST(pedGroup)) then
				SET_RELATIONSHIP_BETWEEN_GROUPS(5, cloneGroup, pedGroup);
			end
		end
	end
end