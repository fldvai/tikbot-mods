ScriptInfo = {
    Name = "The Floor Is Lava",
    ScriptId = "player_lavafloor",
    TimedType = "Short",
}

local lastTick;

function OnStart()
    lastTick = GetTickCount();

    SET_ENTITY_PROOFS(PLAYER_PED_ID(), false, false, false, false, false, false, true, false);
    SET_PED_CONFIG_FLAG(PLAYER_PED_ID(), 430, true);
end

function GetMaxHealth()
    return GET_PED_MAX_HEALTH(PLAYER_PED_ID());
end

function DamagePlayer()
    APPLY_DAMAGE_TO_PED(PLAYER_PED_ID(), math.ceil(GetMaxHealth() / 200), false);
    PLAY_PAIN(PLAYER_PED_ID(), 8, 0, false);
    if not IS_ENTITY_ON_FIRE(PLAYER_PED_ID()) then
        START_ENTITY_FIRE(PLAYER_PED_ID());
    end
end

function OnStop()
    SET_PED_CONFIG_FLAG(PLAYER_PED_ID(), 430, false);
    STOP_ENTITY_FIRE(PLAYER_PED_ID());
end

function OnTick()
    local curTick = GetTickCount();

    if curTick - lastTick >= 200 then
        lastTick = curTick;

        local player = PLAYER_PED_ID();
        local playerPos = GET_ENTITY_COORDS(player);

        local groundz = Holder();
        GET_GROUND_Z_EXCLUDING_OBJECTS_FOR_3D_COORD(playerPos.x, playerPos.y, playerPos.z, groundz, false, false);

        if IS_PED_ON_FOOT(player) and playerPos.z - groundz:AsFloat() < 1.2 then
            local targetCoords = GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player, 0.0, 0.0, -2.0);
            local rayHandle    = START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE(playerPos.x, playerPos.y, playerPos.z,
                targetCoords.x, targetCoords.y, targetCoords.z, 30, player, 4);
            if rayHandle ~= 0 then
                local didHit, endCoords, hitCoordsNormal, entityHandle = Holder(), Holder(), Holder(), Holder();
                local result = GET_SHAPE_TEST_RESULT(rayHandle, didHit, endCoords, hitCoordsNormal, entityHandle);
                if result == 2 then
                    if didHit:AsBoolean() then
                        STOP_ENTITY_FIRE(player);
                    else
                        DamagePlayer()
                    end
                end
            end
        else
            STOP_ENTITY_FIRE(player);
        end
    end
end
